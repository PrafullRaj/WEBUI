import streamlit as st
import pandas as pd
from datetime import datetime, timedelta
from io import BytesIO

# =========================
# App config
# =========================
st.set_page_config(
    page_title="Apigee Analytics Dashboard",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# =========================
# Custom CSS for beautiful UI
# =========================
st.markdown("""
<style>
    /* Main theme colors */
    :root {
        --primary-color: #0F9D58;
        --secondary-color: #4285F4;
        --accent-color: #F4B400;
        --danger-color: #DB4437;
        --bg-color: #F8F9FA;
    }
    
    /* Header styling */
    .main-header {
        background: linear-gradient(135deg, #0F9D58 0%, #4285F4 100%);
        padding: 2rem;
        border-radius: 10px;
        color: white;
        margin-bottom: 2rem;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }
    
    .main-header h1 {
        font-size: 2.5rem;
        font-weight: 700;
        margin: 0;
        color: white !important;
    }
    
    .main-header p {
        font-size: 1.1rem;
        margin: 0.5rem 0 0 0;
        opacity: 0.95;
    }
    
    /* Futuristic Metric Cards - Glassmorphism Style */
    .metric-card {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(10px);
        padding: 2rem 1.5rem;
        border-radius: 20px;
        box-shadow: 0 8px 32px rgba(15, 157, 88, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.3);
        transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        position: relative;
        overflow: hidden;
        margin-bottom: 1.5rem;
        min-height: 140px;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
    }
    
    .metric-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 4px;
        background: linear-gradient(90deg, #0F9D58 0%, #4285F4 50%, #0F9D58 100%);
        background-size: 200% 100%;
        animation: shimmer 3s infinite;
    }
    
    @keyframes shimmer {
        0% { background-position: -200% 0; }
        100% { background-position: 200% 0; }
    }
    
    .metric-card::after {
        content: '';
        position: absolute;
        top: -50%;
        right: -50%;
        width: 100%;
        height: 100%;
        background: radial-gradient(circle, rgba(15, 157, 88, 0.1) 0%, transparent 70%);
        transition: all 0.4s;
    }
    
    .metric-card:hover {
        transform: translateY(-6px);
        box-shadow: 0 12px 40px rgba(15, 157, 88, 0.2);
        border-color: rgba(15, 157, 88, 0.3);
    }
    
    .metric-card:hover::after {
        top: -30%;
        right: -30%;
    }
    
    .metric-label {
        font-size: 0.8rem;
        color: #5F6368;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 1.2px;
        margin-bottom: 1rem;
        opacity: 0.85;
        position: relative;
        z-index: 1;
    }
    
    .metric-value {
        font-size: 2.8rem;
        font-weight: 800;
        margin: 0;
        line-height: 1.1;
        background: linear-gradient(135deg, #0F9D58 0%, #4285F4 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        position: relative;
        z-index: 1;
        letter-spacing: -1px;
    }
    
    .metric-value small {
        font-size: 0.9rem;
        font-weight: 600;
        opacity: 0.8;
        -webkit-text-fill-color: #5F6368;
        display: block;
        margin-top: 0.3rem;
    }
    
    .metric-subtext {
        font-size: 0.7rem;
        color: #5F6368;
        margin-top: 0.5rem;
        opacity: 0.7;
        position: relative;
        z-index: 1;
        line-height: 1.3;
    }
    
    /* Metrics Container */
    .metrics-container {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 1.5rem;
        margin: 2rem 0;
    }
    
    @media (max-width: 1200px) {
        .metrics-container {
            grid-template-columns: repeat(2, 1fr);
        }
    }
    
    /* Status badges */
    .status-active {
        background: #E8F5E9;
        color: #2E7D32;
        padding: 0.25rem 0.75rem;
        border-radius: 12px;
        font-weight: 600;
        font-size: 0.85rem;
        display: inline-block;
    }
    
    .status-inactive {
        background: #FFEBEE;
        color: #C62828;
        padding: 0.25rem 0.75rem;
        border-radius: 12px;
        font-weight: 600;
        font-size: 0.85rem;
        display: inline-block;
    }
    
    /* Info cards */
    .info-card {
        background: linear-gradient(135deg, #667EEA 0%, #764BA2 100%);
        padding: 1.5rem;
        border-radius: 10px;
        color: white;
        margin: 1rem 0;
    }
    
    .info-card h3 {
        color: white !important;
        margin: 0 0 0.5rem 0;
    }
    
    /* Sidebar styling */
    .css-1d391kg {
        background: #F8F9FA;
    }
    
    /* Data tables - Professional Look */
    .dataframe {
        border: none !important;
        box-shadow: 0 2px 12px rgba(0,0,0,0.08);
        border-radius: 12px;
        overflow: hidden;
    }
    
    .dataframe thead {
        background: linear-gradient(135deg, #0F9D58 0%, #4285F4 100%);
        color: white;
    }
    
    .dataframe tbody tr:hover {
        background: #F5F5F5;
        transition: background 0.2s;
    }
    
    /* Tabs - Smooth and Professional */
    .stTabs [data-baseweb="tab-list"] {
        gap: 4px;
        background: #F8F9FA;
        padding: 8px 8px 0 8px;
        border-radius: 12px 12px 0 0;
    }
    
    .stTabs [data-baseweb="tab"] {
        height: 48px;
        background-color: white;
        border-radius: 10px 10px 0 0;
        padding: 0 20px;
        font-weight: 600;
        color: #5F6368;
        border: none;
        transition: all 0.3s ease;
        box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    }
    
    .stTabs [data-baseweb="tab"]:hover {
        background: #F1F3F4;
        transform: translateY(-2px);
    }
    
    .stTabs [aria-selected="true"] {
        background: linear-gradient(135deg, #0F9D58 0%, #4285F4 100%);
        color: white !important;
        box-shadow: 0 4px 12px rgba(15, 157, 88, 0.3);
        transform: translateY(-2px);
    }
    
    /* Buttons - Smooth Transitions */
    .stButton>button {
        background: linear-gradient(135deg, #0F9D58 0%, #4285F4 100%);
        color: white;
        border: none;
        padding: 0.6rem 1.8rem;
        border-radius: 10px;
        font-weight: 600;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        box-shadow: 0 2px 8px rgba(15, 157, 88, 0.2);
    }
    
    .stButton>button:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 16px rgba(15, 157, 88, 0.4);
    }
    
    .stButton>button:active {
        transform: translateY(0);
    }
    
    /* Chat messages */
    .stChatMessage {
        background: white;
        border-radius: 10px;
        padding: 1rem;
        margin: 0.5rem 0;
        box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    }
    
    /* Download buttons */
    .stDownloadButton>button {
        background: #F4B400;
        color: #202124;
        border: none;
        padding: 0.5rem 1.5rem;
        border-radius: 8px;
        font-weight: 600;
    }
    
    .stDownloadButton>button:hover {
        background: #F4B400;
        opacity: 0.9;
        transform: scale(1.05);
    }
    
    /* Section headers */
    .section-header {
        color: #202124;
        font-size: 1.5rem;
        font-weight: 700;
        margin: 2rem 0 1rem 0;
        padding-bottom: 0.5rem;
        border-bottom: 3px solid #0F9D58;
    }
    
    /* Info boxes */
    .stInfo {
        background: #E3F2FD !important;
        border-left: 4px solid #2196F3 !important;
        border-radius: 8px !important;
    }
    
    /* Success boxes */
    .stSuccess {
        background: #E8F5E9 !important;
        border-left: 4px solid #4CAF50 !important;
        border-radius: 8px !important;
    }
    
    /* Error boxes */
    .stError {
        background: #FFEBEE !important;
        border-left: 4px solid #F44336 !important;
        border-radius: 8px !important;
    }
</style>
""", unsafe_allow_html=True)

# =========================
# Data loading (Excel with multiple sheets)
# =========================
@st.cache_data(show_spinner=True)
def load_data(file_path: str = "apigee_data.xlsx",
              main_sheet: str = "Sheet1",
              apps_sheet: str = "Sheet2",
              apim_sheet: str = "Sheet3"):
    # Read main API metadata sheet
    proxy_df = pd.read_excel(file_path, sheet_name=main_sheet)
    
    # Try to read apps/products sheet (optional)
    try:
        apps_df = pd.read_excel(file_path, sheet_name=apps_sheet)
    except Exception:
        # If Sheet2 doesn't exist, create empty dataframe
        apps_df = pd.DataFrame()
    
    # Try to read APIM sheet (optional)
    try:
        apim_df = pd.read_excel(file_path, sheet_name=apim_sheet)
    except Exception:
        # If Sheet3 doesn't exist, create empty dataframe
        apim_df = pd.DataFrame()
    
    # Process main proxy dataframe
    df = proxy_df

    # Normalize date columns
    for col in ["Prod Move Date", "Proxy Created Date"]:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors="coerce")

    # Handle numeric ID columns specially (remove decimal points)
    id_columns = ["Provider APP ID", "Consumer App ID"]
    for col in id_columns:
        if col in df.columns:
            def clean_id(val):
                """Convert ID to clean integer string, handling floats and text."""
                if pd.isna(val):
                    return ""
                # If it's already a string (not a number), keep it
                if isinstance(val, str):
                    return val.strip()
                # If it's a number, convert to int (removes .0) then to string
                try:
                    # Convert to float first (in case it's int), then to int, then string
                    return str(int(float(val)))
                except (ValueError, TypeError):
                    # If conversion fails, just stringify it
                    return str(val)
            
            df[col] = df[col].apply(clean_id)
    
    # Normalize text columns to avoid None and NaN
    text_columns = [
        "API Protocol (REST / SOAP)",
        "Request Type(GET/POST/DELETE/PUT)",
        "Status(A/D)",
        "Prod API Proxies",
        "Provider App Name",
        "Consumer App Name",
        "APIGEE URL",
        "Backend URL",
        "Quota Limit",
        "Spike Arrest",
        "API Description",
        "Authentication",
        "Internet/Intranet Exposed",
        "Assigned To",
    ]
    for col in text_columns:
        if col in df.columns:
            # Fill NaN first, then convert to string
            df[col] = df[col].fillna("").astype(str)
            # Replace string 'nan' with empty string
            df[col] = df[col].replace(['nan', 'None', 'NaN'], "")
    
    # Process apps dataframe if it exists
    if not apps_df.empty:
        for col in ["API Proxy Name", "Product Name", "Developer App", "Assigned To"]:
            if col in apps_df.columns:
                apps_df[col] = apps_df[col].fillna("").astype(str)
                apps_df[col] = apps_df[col].replace(['nan', 'None', 'NaN'], "")
    
    # Process APIM dataframe if it exists (similar processing)
    if not apim_df.empty:
        # Normalize date columns for APIM
        for col in ["Prod Move Date", "Proxy Created Date"]:
            if col in apim_df.columns:
                apim_df[col] = pd.to_datetime(apim_df[col], errors="coerce")
        
        # Handle numeric ID columns for APIM
        for col in id_columns:
            if col in apim_df.columns:
                def clean_id(val):
                    if pd.isna(val):
                        return ""
                    if isinstance(val, str):
                        return val.strip()
                    try:
                        return str(int(float(val)))
                    except (ValueError, TypeError):
                        return str(val)
                apim_df[col] = apim_df[col].apply(clean_id)
        
        # Normalize text columns for APIM (including APIM-specific URLs)
        apim_text_columns = [
            "API Protocol (REST / SOAP)",
            "Request Type(GET/POST/DELETE/PUT)",
            "Status(A/D)",
            "Prod API Proxies",
            "Provider App Name",
            "Consumer App Name",
            "APIM Prod URL",
            "APIM DR URL",
            "Backend Prod URL",
            "Backend DR URL",
            "Quota Limit",
            "Spike Arrest",
            "API Description",
            "Authentication",
            "Internet/Intranet Exposed",
            "Assigned To",
        ]
        for col in apim_text_columns:
            if col in apim_df.columns:
                apim_df[col] = apim_df[col].fillna("").astype(str)
                apim_df[col] = apim_df[col].replace(['nan', 'None', 'NaN'], "")

    return df, apps_df, apim_df

# =========================
# Utilities
# =========================
def df_to_excel_bytes(df: pd.DataFrame, sheet_name: str = "results") -> bytes:
    output = BytesIO()
    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name=sheet_name)
    return output.getvalue()

def get_proxy_row(df: pd.DataFrame, proxy_name: str) -> pd.DataFrame:
    return df[df["Prod API Proxies"] == proxy_name]

def safe_get(row, col: str):
    """
    Safely get a value from a dataframe row or series, handling NaN, empty, and None values.
    Handles both DataFrame and Series objects.
    If the first row has NaN/empty, it will search through all rows to find a valid value.
    """
    try:
        # Handle empty case
        if hasattr(row, 'empty') and row.empty:
            return "N/A"
        
        # Handle Series (single row)
        if isinstance(row, pd.Series):
            if col not in row.index:
                return "N/A"
            val = row[col]
            if pd.isna(val):
                return "N/A"
            val_str = str(val).strip()
            if val_str == "" or val_str.lower() in ["nan", "none"]:
                return "N/A"
            return val_str
        
        # Handle DataFrame (multiple rows)
        if isinstance(row, pd.DataFrame):
            if col not in row.columns:
                return "N/A"
            
            # Try all rows in the dataframe to find the first valid value
            for idx in range(len(row)):
                val = row[col].iloc[idx]
                
                # Skip if NaN
                if pd.isna(val):
                    continue
                
                # Convert to string and clean up
                val_str = str(val).strip()
                
                # Skip if empty or "nan"/"none" string
                if val_str == "" or val_str.lower() in ["nan", "none"]:
                    continue
                
                # Found a valid value!
                return val_str
        
        # If it's neither Series nor DataFrame, return N/A
        return "N/A"
        
    except (AttributeError, TypeError, KeyError, IndexError) as e:
        return "N/A"

# =========================
# Initialize session state for page routing
# =========================
if "current_page" not in st.session_state:
    st.session_state.current_page = "home"

# =========================
# Home Page Function
# =========================
def show_home_page():
    st.markdown("""
    <div class="main-header">
        <h1>🚀 API Analytics Dashboard</h1>
        <p>Unified Platform for Apigee & APIM Analytics</p>
    </div>
    """, unsafe_allow_html=True)
    
    st.markdown("""
    <div style="text-align: center; margin: 3rem 0;">
        <h2 style="color: #202124; font-size: 2rem; font-weight: 700; margin-bottom: 2rem;">
            Choose Your Analytics Platform
        </h2>
    </div>
    """, unsafe_allow_html=True)
    
    col1, col2 = st.columns(2, gap="large")
    
    with col1:
        st.markdown("""
        <div style="background: linear-gradient(135deg, #0F9D58 0%, #4285F4 100%);
                    padding: 3rem 2rem;
                    border-radius: 20px;
                    color: white;
                    text-align: center;
                    box-shadow: 0 8px 32px rgba(15, 157, 88, 0.2);
                    transition: transform 0.3s;
                    cursor: pointer;
                    min-height: 400px;
                    display: flex;
                    flex-direction: column;
                    justify-content: center;">
            <h2 style="color: white; font-size: 2.5rem; margin-bottom: 1rem;">📊</h2>
            <h2 style="color: white; font-size: 1.8rem; margin-bottom: 1rem;">Apigee Analytics</h2>
            <p style="color: white; font-size: 1.1rem; opacity: 0.95; margin: 0;">
                Comprehensive API Proxy Management & Insights<br>
                • Developer Apps & Products<br>
                • Consumer Analytics<br>
                • Lifecycle Tracking<br>
                • AI Assistant
            </p>
        </div>
        """, unsafe_allow_html=True)
        if st.button("🚀 Open Apigee Dashboard", key="btn_apigee", use_container_width=True):
            st.session_state.current_page = "apigee"
            st.rerun()
    
    with col2:
        st.markdown("""
        <div style="background: linear-gradient(135deg, #667EEA 0%, #764BA2 100%);
                    padding: 3rem 2rem;
                    border-radius: 20px;
                    color: white;
                    text-align: center;
                    box-shadow: 0 8px 32px rgba(102, 126, 234, 0.2);
                    transition: transform 0.3s;
                    cursor: pointer;
                    min-height: 400px;
                    display: flex;
                    flex-direction: column;
                    justify-content: center;">
            <h2 style="color: white; font-size: 2.5rem; margin-bottom: 1rem;">🔷</h2>
            <h2 style="color: white; font-size: 1.8rem; margin-bottom: 1rem;">APIM Analytics</h2>
            <p style="color: white; font-size: 1.1rem; opacity: 0.95; margin: 0;">
                Azure API Management Insights<br>
                • Production & DR URLs<br>
                • Consumer Analytics<br>
                • Lifecycle Tracking<br>
                • AI Assistant
            </p>
        </div>
        """, unsafe_allow_html=True)
        if st.button("🚀 Open APIM Dashboard", key="btn_apim", use_container_width=True):
            st.session_state.current_page = "apim"
            st.rerun()
    
    st.markdown("<br><br>", unsafe_allow_html=True)
    
    st.info("💡 **Tip:** Select a platform above to access its dedicated analytics dashboard with platform-specific features and insights.")

# =========================
# Load data (with error handling)
# =========================
try:
    proxy_df, apps_df, apim_df = load_data()
except FileNotFoundError:
    st.error("⚠️ **File not found**: `apigee_data.xlsx` is required but not found in the current directory.")
    st.info("Please ensure the Excel file exists with sheets 'Sheet1', 'Sheet2', and 'Sheet3'.")
    st.stop()
except Exception as e:
    st.error(f"⚠️ **Error loading data**: {str(e)}")
    st.stop()

# =========================
# Route to appropriate page
# =========================
if st.session_state.current_page == "home":
    show_home_page()
    st.stop()
elif st.session_state.current_page == "apim":
    # =========================
    # APIM Dashboard Code
    # =========================
    # Check if APIM data is available
    if apim_df.empty or "Prod API Proxies" not in apim_df.columns:
        st.sidebar.markdown("""
        <div style="background: linear-gradient(135deg, #667EEA 0%, #764BA2 100%); 
                    padding: 1.5rem; border-radius: 10px; margin-bottom: 1.5rem;">
            <h2 style="color: white; margin: 0; font-size: 1.5rem;">🔷 APIM Dashboard</h2>
        </div>
        """, unsafe_allow_html=True)
        
        if st.sidebar.button("🏠 Back to Home", use_container_width=True):
            st.session_state.current_page = "home"
            st.rerun()
        
        st.error("⚠️ **No APIM data available**: Sheet3 is required but not found or empty.")
        st.info("💡 Please ensure the Excel file contains 'Sheet3' with APIM data.")
        st.stop()
    
    # Sidebar: Search & controls
    st.sidebar.markdown("""
    <div style="background: linear-gradient(135deg, #667EEA 0%, #764BA2 100%); 
                padding: 1.5rem; border-radius: 10px; margin-bottom: 1.5rem;">
        <h2 style="color: white; margin: 0; font-size: 1.5rem;">🔷 APIM Dashboard</h2>
    </div>
    """, unsafe_allow_html=True)
    
    if st.sidebar.button("🏠 Back to Home", key="back_home_apim", use_container_width=True):
        st.session_state.current_page = "home"
        st.rerun()
    
    st.sidebar.markdown("---")
    st.sidebar.markdown("""
    <div style="background: linear-gradient(135deg, #667EEA 0%, #764BA2 100%); 
                padding: 1.5rem; border-radius: 10px; margin-bottom: 1.5rem;">
        <h2 style="color: white; margin: 0; font-size: 1.5rem;">🔍 Search & Filters</h2>
    </div>
    """, unsafe_allow_html=True)
    
    proxy_list_apim = sorted(apim_df["Prod API Proxies"].dropna().unique().tolist())
    
    if not proxy_list_apim:
        st.error("⚠️ **No data**: No proxy names found in the 'Prod API Proxies' column. Please check Sheet3.")
        st.stop()
    
    st.sidebar.markdown("### 📋 Select API Proxy")
    selected_proxy_apim = st.sidebar.selectbox("Choose a proxy to analyze", proxy_list_apim, label_visibility="collapsed", key="apim_proxy_select")
    
    st.sidebar.markdown("---")
    
    # Refresh data
    if st.sidebar.button("🔄 Refresh Data", key="apim_refresh", use_container_width=True):
        load_data.clear()
        proxy_df, apps_df, apim_df = load_data()
        st.sidebar.success("✅ Data refreshed!")
        st.rerun()
    
    st.sidebar.markdown("---")
    st.sidebar.markdown("""
    <div style="text-align: center; color: #5F6368; font-size: 0.85rem; padding: 1rem;">
        <strong>APIM Analytics Dashboard</strong><br>
        v1.0 | © 2026
    </div>
    """, unsafe_allow_html=True)
    
    # =========================
    # Header
    # =========================
    st.markdown("""
    <div class="main-header" style="background: linear-gradient(135deg, #667EEA 0%, #764BA2 100%);">
        <h1>🔷 APIM Analytics Dashboard</h1>
        <p>Azure API Management Insights & Analytics</p>
    </div>
    """, unsafe_allow_html=True)
    
    # =========================
    # Dashboard Summary Analytics
    # =========================
    unique_proxies_apim_df = apim_df[apim_df["Prod API Proxies"].notna()].drop_duplicates(subset=["Prod API Proxies"])
    
    total_proxies_apim = len(unique_proxies_apim_df)
    
    if "Status(A/D)" in unique_proxies_apim_df.columns:
        status_series_apim = unique_proxies_apim_df["Status(A/D)"].astype(str).str.upper().str.strip()
        active_proxies_apim = (status_series_apim == "A").sum()
        decom_proxies_apim = (status_series_apim == "D").sum()
    else:
        active_proxies_apim = 0
        decom_proxies_apim = 0
    active_percentage_apim = round((active_proxies_apim / total_proxies_apim * 100), 1) if total_proxies_apim > 0 else 0
    
    unique_providers_apim = apim_df["Provider App Name"].nunique() if "Provider App Name" in apim_df.columns else 0
    unique_consumers_apim = apim_df["Consumer App Name"].nunique() if "Consumer App Name" in apim_df.columns else 0
    
    rest_count_apim = unique_proxies_apim_df[unique_proxies_apim_df["API Protocol (REST / SOAP)"].str.upper() == "REST"].shape[0] if "API Protocol (REST / SOAP)" in apim_df.columns else 0
    soap_count_apim = unique_proxies_apim_df[unique_proxies_apim_df["API Protocol (REST / SOAP)"].str.upper() == "SOAP"].shape[0] if "API Protocol (REST / SOAP)" in apim_df.columns else 0
    
    # Total unique endpoints (APIM Prod URLs)
    total_endpoints_apim = apim_df["APIM Prod URL"].dropna().nunique() if "APIM Prod URL" in apim_df.columns else 0
    
    cutoff_30days = pd.Timestamp(datetime.now() - timedelta(days=30))
    recent_created_apim = apim_df[(apim_df["Proxy Created Date"].notna()) & (apim_df["Proxy Created Date"] >= cutoff_30days)]["Prod API Proxies"].nunique()
    recent_moved_apim = apim_df[(apim_df["Prod Move Date"].notna()) & (apim_df["Prod Move Date"] >= cutoff_30days)]["Prod API Proxies"].nunique()
    recent_activity_apim = max(recent_created_apim, recent_moved_apim)
    
    st.markdown("""
    <div style="margin: 2.5rem 0 2rem 0; text-align: center;">
        <h2 style="color: #202124; font-size: 2rem; font-weight: 800; margin-bottom: 0.5rem; letter-spacing: -0.5px;">
            📊 Key Metrics Dashboard
        </h2>
        <p style="color: #5F6368; font-size: 1rem; margin: 0; font-weight: 500;">Real-time analytics & insights</p>
    </div>
    """, unsafe_allow_html=True)
    
    oauth_count_apim = unique_proxies_apim_df[unique_proxies_apim_df["Authentication"].str.contains("Oauth", case=False, na=False)].shape[0]
    internet_count_apim = unique_proxies_apim_df[unique_proxies_apim_df["Internet/Intranet Exposed"].str.contains("Internet", case=False, na=False)].shape[0]
    intranet_count_apim = unique_proxies_apim_df[unique_proxies_apim_df["Internet/Intranet Exposed"].str.contains("Intranet", case=False, na=False)].shape[0]
    internet_percentage_apim = round((internet_count_apim / total_proxies_apim * 100), 1) if total_proxies_apim > 0 else 0
    intranet_percentage_apim = round((intranet_count_apim / total_proxies_apim * 100), 1) if total_proxies_apim > 0 else 0
    
    # First row - Core Metrics
    st.markdown("<div style='margin-bottom: 1.5rem;'></div>", unsafe_allow_html=True)
    col1, col2, col3, col4 = st.columns(4, gap="large")
    
    with col1:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">Total API Proxies</div>
            <div class="metric-value">{total_proxies_apim}</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">Active APIs</div>
            <div class="metric-value">{active_proxies_apim}<small>({active_percentage_apim}%)</small></div>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">Decommissioned</div>
            <div class="metric-value">{decom_proxies_apim}</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col4:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">Unique Endpoints</div>
            <div class="metric-value">{total_endpoints_apim}</div>
            <div class="metric-subtext">Unique APIM Prod URLs</div>
        </div>
        """, unsafe_allow_html=True)
    
    # Second row
    st.markdown("<div style='margin-bottom: 1.5rem;'></div>", unsafe_allow_html=True)
    col5, col6, col7, col8 = st.columns(4, gap="large")
    
    with col5:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">Unique Providers</div>
            <div class="metric-value">{unique_providers_apim}</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col6:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">Unique Consumers</div>
            <div class="metric-value">{unique_consumers_apim}</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col7:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">REST APIs</div>
            <div class="metric-value">{rest_count_apim}</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col8:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">SOAP APIs</div>
            <div class="metric-value">{soap_count_apim}</div>
        </div>
        """, unsafe_allow_html=True)
    
    # Third row
    st.markdown("<div style='margin-bottom: 1.5rem;'></div>", unsafe_allow_html=True)
    col9, col10, col11, col12 = st.columns(4, gap="large")
    
    with col9:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">Recent Activity (30d)</div>
            <div class="metric-value">{recent_activity_apim}</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col10:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">OAuth Protected</div>
            <div class="metric-value">{oauth_count_apim}</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col11:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">🌐 Internet Exposed</div>
            <div class="metric-value">{internet_count_apim}</div>
            <div class="metric-subtext">{internet_percentage_apim}% of total</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col12:
        st.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">🔒 Intranet Only</div>
            <div class="metric-value">{intranet_count_apim}</div>
            <div class="metric-subtext">{intranet_percentage_apim}% of total</div>
        </div>
        """, unsafe_allow_html=True)
    
    st.markdown("<div style='margin-bottom: 2rem;'></div>", unsafe_allow_html=True)
    
    # =========================
    # Tabs: Overview, Consumers, Date Filter, URL Search, Lifecycle, AI Assistant (NO Developer Apps)
    # =========================
    tab_overview_apim, tab_consumers_apim, tab_date_filter_apim, tab_url_search_apim, tab_lifecycle_apim, tab_chat_apim = st.tabs([
        "🔍 Overview", 
        "👥 Consumers",
        "📅 Date Filter",
        "🔗 URL Search",
        "📈 Lifecycle", 
        "💬 AI Assistant"
    ])
    
    row_apim = get_proxy_row(apim_df, selected_proxy_apim)
    
    with tab_overview_apim:
        st.markdown(f'<h2 class="section-header">📋 {selected_proxy_apim}</h2>', unsafe_allow_html=True)
        
        status_apim = safe_get(row_apim, "Status(A/D)")
        status_class_apim = "status-active" if status_apim.upper() == "A" else "status-inactive"
        status_text_apim = "Active ✓" if status_apim.upper() == "A" else "Decommissioned ✗"
        st.markdown(f'<span class="{status_class_apim}">{status_text_apim}</span>', unsafe_allow_html=True)
        
        st.markdown("<br>", unsafe_allow_html=True)
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("##### 🔧 Technical Details")
            st.markdown(f"""
            - **Protocol:** {safe_get(row_apim, 'API Protocol (REST / SOAP)')}
            - **Methods:** {safe_get(row_apim, 'Request Type(GET/POST/DELETE/PUT)')}
            - **Authentication:** {safe_get(row_apim, 'Authentication')}
            - **Exposure:** {safe_get(row_apim, 'Internet/Intranet Exposed')}
            """)
        
        with col2:
            st.markdown("##### ⚙️ Rate Limits")
            st.markdown(f"""
            - **Quota Limit:** {safe_get(row_apim, 'Quota Limit')}
            - **Spike Arrest:** {safe_get(row_apim, 'Spike Arrest')}
            """)
        
        st.markdown("<br>", unsafe_allow_html=True)
        st.markdown("##### 📝 Description")
        description_apim = safe_get(row_apim, 'API Description')
        st.info(description_apim if description_apim != "N/A" else "No description available.")
        
        st.markdown("<br>", unsafe_allow_html=True)
        st.markdown("##### 🔗 Endpoints")
        # APIM has Prod and DR URLs
        url_cols = ["APIM Prod URL", "APIM DR URL", "Backend Prod URL", "Backend DR URL", "Request Type(GET/POST/DELETE/PUT)"]
        available_url_cols = [col for col in url_cols if col in apim_df.columns]
        urls_df_apim = apim_df[apim_df["Prod API Proxies"] == selected_proxy_apim][available_url_cols]
        if urls_df_apim.empty:
            st.warning("⚠️ No APIM or Backend URLs found for this proxy.")
        else:
            st.dataframe(urls_df_apim, width='stretch', hide_index=True)
    
    with tab_consumers_apim:
        st.markdown('<h2 class="section-header">👥 Consumers of {}</h2>'.format(selected_proxy_apim), unsafe_allow_html=True)
        
        proxy_data_apim = apim_df[apim_df["Prod API Proxies"] == selected_proxy_apim]
        
        if proxy_data_apim.empty:
            st.warning("⚠️ No consumer data found for this proxy.")
        else:
            consumers_apim = sorted([c for c in proxy_data_apim["Consumer App Name"].dropna().unique().tolist() if c and c != ""])
            
            if not consumers_apim:
                st.info("ℹ️ No specific consumers identified for this proxy.")
            else:
                st.info(f"💡 **Tip:** Select a consumer to see all endpoints they consume")
                st.metric("Total Unique Consumers", len(consumers_apim))
                
                selected_consumer_apim = st.selectbox(
                    "Select Consumer to View Details:",
                    ["-- Select a Consumer --"] + consumers_apim,
                    key="consumer_select_apim"
                )
                
                if selected_consumer_apim and selected_consumer_apim != "-- Select a Consumer --":
                    st.markdown(f"### 📊 Details for **{selected_consumer_apim}**")
                    
                    consumer_endpoints_apim = proxy_data_apim[proxy_data_apim["Consumer App Name"] == selected_consumer_apim]
                    
                    if consumer_endpoints_apim.empty:
                        st.info("No endpoint details available.")
                    else:
                        apim_prod_urls = [url for url in consumer_endpoints_apim["APIM Prod URL"].dropna().unique().tolist() if url and url != ""] if "APIM Prod URL" in consumer_endpoints_apim.columns else []
                        apim_dr_urls = [url for url in consumer_endpoints_apim["APIM DR URL"].dropna().unique().tolist() if url and url != ""] if "APIM DR URL" in consumer_endpoints_apim.columns else []
                        backend_prod_urls = [url for url in consumer_endpoints_apim["Backend Prod URL"].dropna().unique().tolist() if url and url != ""] if "Backend Prod URL" in consumer_endpoints_apim.columns else []
                        backend_dr_urls = [url for url in consumer_endpoints_apim["Backend DR URL"].dropna().unique().tolist() if url and url != ""] if "Backend DR URL" in consumer_endpoints_apim.columns else []
                        
                        col1, col2 = st.columns(2)
                        with col1:
                            st.metric("APIM Prod Endpoints", len(apim_prod_urls))
                        with col2:
                            st.metric("Backend Prod Endpoints", len(backend_prod_urls))
                        
                        with st.expander("🔗 APIM Prod URLs", expanded=True):
                            if apim_prod_urls:
                                for url in apim_prod_urls:
                                    st.code(url, language=None)
                            else:
                                st.info("No APIM Prod URLs found")
                        
                        if apim_dr_urls:
                            with st.expander("🔗 APIM DR URLs", expanded=False):
                                for url in apim_dr_urls:
                                    st.code(url, language=None)
                        
                        with st.expander("🔗 Backend Prod URLs", expanded=True):
                            if backend_prod_urls:
                                for url in backend_prod_urls:
                                    st.code(url, language=None)
                            else:
                                st.info("No Backend Prod URLs found")
                        
                        if backend_dr_urls:
                            with st.expander("🔗 Backend DR URLs", expanded=False):
                                for url in backend_dr_urls:
                                    st.code(url, language=None)
                        
                        st.markdown("### 📋 Complete Endpoint Details:")
                        endpoint_cols = ["APIM Prod URL", "APIM DR URL", "Backend Prod URL", "Backend DR URL", "Request Type(GET/POST/DELETE/PUT)"]
                        available_endpoint_cols = [col for col in endpoint_cols if col in consumer_endpoints_apim.columns]
                        endpoint_details_apim = consumer_endpoints_apim[available_endpoint_cols].drop_duplicates()
                        st.dataframe(endpoint_details_apim, width='stretch', hide_index=True)
                        
                        excel_bytes_apim = df_to_excel_bytes(endpoint_details_apim)
                        st.download_button(
                            label=f"📥 Download {selected_consumer_apim} Endpoints",
                            data=excel_bytes_apim,
                            file_name=f"{selected_consumer_apim}_{selected_proxy_apim}_endpoints.xlsx",
                            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                            key="download_consumer_endpoints_apim",
                            width='stretch'
                        )
    
    with tab_date_filter_apim:
        st.markdown('<h2 class="section-header">📅 Date-Based Proxy Filter</h2>', unsafe_allow_html=True)
        st.info("💡 **Filter proxies by creation date or production move date within a specific date range**")
        
        filter_type_apim = st.radio(
            "Select Date Type:",
            ["📅 Proxy Created Date", "🚀 Production Move Date"],
            horizontal=True,
            key="date_filter_type_apim"
        )
        
        col1, col2 = st.columns(2)
        
        with col1:
            start_date_apim = st.date_input(
                "Start Date:",
                value=datetime.now().date() - timedelta(days=365),
                key="start_date_apim"
            )
        
        with col2:
            end_date_apim = st.date_input(
                "End Date:",
                value=datetime.now().date(),
                key="end_date_apim"
            )
        
        if start_date_apim > end_date_apim:
            st.error("⚠️ Start date must be before end date!")
        else:
            if filter_type_apim == "📅 Proxy Created Date":
                date_col_apim = "Proxy Created Date"
                filter_label_apim = "Created"
            else:
                date_col_apim = "Prod Move Date"
                filter_label_apim = "Moved to Production"
            
            filtered_proxies_apim = apim_df[
                (apim_df[date_col_apim].notna()) &
                (pd.to_datetime(apim_df[date_col_apim]).dt.date >= start_date_apim) &
                (pd.to_datetime(apim_df[date_col_apim]).dt.date <= end_date_apim)
            ]
            
            unique_proxies_apim = filtered_proxies_apim.drop_duplicates(subset=["Prod API Proxies"])
            
            if unique_proxies_apim.empty:
                st.warning(f"⚠️ No proxies found {filter_label_apim.lower()} between {start_date_apim} and {end_date_apim}")
            else:
                st.success(f"✅ Found **{len(unique_proxies_apim)}** unique proxies {filter_label_apim.lower()} in this date range")
                
                col1, col2, col3 = st.columns(3)
                with col1:
                    active_count_apim = unique_proxies_apim[unique_proxies_apim["Status(A/D)"].str.upper() == "A"].shape[0] if "Status(A/D)" in unique_proxies_apim.columns else 0
                    st.metric("Active", active_count_apim)
                with col2:
                    rest_count_filter_apim = unique_proxies_apim[unique_proxies_apim["API Protocol (REST / SOAP)"].str.upper() == "REST"].shape[0] if "API Protocol (REST / SOAP)" in unique_proxies_apim.columns else 0
                    st.metric("REST APIs", rest_count_filter_apim)
                with col3:
                    oauth_count_filter_apim = unique_proxies_apim[unique_proxies_apim["Authentication"].str.contains("Oauth", case=False, na=False)].shape[0]
                    st.metric("OAuth Protected", oauth_count_filter_apim)
                
                st.markdown("### 📋 Proxy Details")
                
                display_cols_apim = ["Prod API Proxies", date_col_apim, "Status(A/D)", "Provider App Name", "Consumer App Name"]
                available_cols_apim = [col for col in display_cols_apim if col in unique_proxies_apim.columns]
                
                unique_proxies_sorted_apim = unique_proxies_apim.sort_values(date_col_apim, ascending=False)
                
                st.dataframe(
                    unique_proxies_sorted_apim[available_cols_apim],
                    width='stretch',
                    hide_index=True
                )
                
                excel_bytes_filter_apim = df_to_excel_bytes(unique_proxies_sorted_apim[available_cols_apim])
                st.download_button(
                    label="📥 Download Filtered Proxies",
                    data=excel_bytes_filter_apim,
                    file_name=f"apim_proxies_{filter_label_apim.lower()}_{start_date_apim}_to_{end_date_apim}.xlsx",
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    key="download_date_filtered_apim",
                    width='stretch'
                )
    
    with tab_url_search_apim:
        st.markdown('<h2 class="section-header">🔗 URL Search & Mapping</h2>', unsafe_allow_html=True)
        st.info("💡 **Tip:** Find the corresponding URL by pasting either an APIM or Backend URL")
        
        search_url_apim = st.text_input(
            "Enter URL to search:",
            placeholder="Paste APIM Prod/DR URL or Backend Prod/DR URL here...",
            help="Enter any part of an APIM or Backend URL to find its mapping",
            key="url_search_apim"
        )
        
        if search_url_apim and len(search_url_apim) > 10:
            # Search in APIM URLs
            apim_prod_matches = apim_df[apim_df["APIM Prod URL"].str.contains(search_url_apim, case=False, na=False, regex=False)] if "APIM Prod URL" in apim_df.columns else pd.DataFrame()
            apim_dr_matches = apim_df[apim_df["APIM DR URL"].str.contains(search_url_apim, case=False, na=False, regex=False)] if "APIM DR URL" in apim_df.columns else pd.DataFrame()
            backend_prod_matches = apim_df[apim_df["Backend Prod URL"].str.contains(search_url_apim, case=False, na=False, regex=False)] if "Backend Prod URL" in apim_df.columns else pd.DataFrame()
            backend_dr_matches = apim_df[apim_df["Backend DR URL"].str.contains(search_url_apim, case=False, na=False, regex=False)] if "Backend DR URL" in apim_df.columns else pd.DataFrame()
            
            all_matches_apim = pd.concat([apim_prod_matches, apim_dr_matches, backend_prod_matches, backend_dr_matches]).drop_duplicates()
            
            if not all_matches_apim.empty:
                st.success(f"✅ Found {len(all_matches_apim)} matching URL(s)")
                
                url_cols_mapping = ["Prod API Proxies", "APIM Prod URL", "APIM DR URL", "Backend Prod URL", "Backend DR URL"]
                available_mapping_cols = [col for col in url_cols_mapping if col in all_matches_apim.columns]
                mappings_apim = all_matches_apim[available_mapping_cols].drop_duplicates()
                
                for idx, row in mappings_apim.iterrows():
                    with st.expander(f"🔍 {row['Prod API Proxies']}", expanded=True):
                        if "APIM Prod URL" in row and pd.notna(row["APIM Prod URL"]) and row["APIM Prod URL"]:
                            st.markdown("**APIM Prod URL:**")
                            st.code(row["APIM Prod URL"], language=None)
                        if "Backend Prod URL" in row and pd.notna(row["Backend Prod URL"]) and row["Backend Prod URL"]:
                            st.markdown("**→ Corresponding Backend Prod URL:**")
                            st.code(row["Backend Prod URL"], language=None)
                        if "APIM DR URL" in row and pd.notna(row["APIM DR URL"]) and row["APIM DR URL"]:
                            st.markdown("**APIM DR URL:**")
                            st.code(row["APIM DR URL"], language=None)
                        if "Backend DR URL" in row and pd.notna(row["Backend DR URL"]) and row["Backend DR URL"]:
                            st.markdown("**→ Corresponding Backend DR URL:**")
                            st.code(row["Backend DR URL"], language=None)
                
                excel_bytes_mapping_apim = df_to_excel_bytes(mappings_apim)
                st.download_button(
                    label="📥 Download All Mappings",
                    data=excel_bytes_mapping_apim,
                    file_name="apim_url_mappings.xlsx",
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    key="download_apim_mappings",
                    width='stretch'
                )
            else:
                st.warning(f"❌ No matches found for: `{search_url_apim}`")
                st.info("💡 Try entering a different part of the URL or check for typos")
        
        elif search_url_apim:
            st.info("⌨️ Please enter at least 10 characters to search")
    
    with tab_lifecycle_apim:
        st.markdown(f'<h2 class="section-header">📈 Lifecycle & Timeline - {selected_proxy_apim}</h2>', unsafe_allow_html=True)
        
        proxy_lifecycle_data_apim = apim_df[apim_df["Prod API Proxies"] == selected_proxy_apim]
        
        if proxy_lifecycle_data_apim.empty:
            st.warning("⚠️ No lifecycle data found for this proxy.")
        else:
            created_dates_apim = proxy_lifecycle_data_apim["Proxy Created Date"].dropna().unique()
            prod_dates_apim = proxy_lifecycle_data_apim["Prod Move Date"].dropna().unique()
            
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.markdown("##### 📅 Created Date")
                if len(created_dates_apim) > 0:
                    created_date_apim = pd.to_datetime(created_dates_apim[0])
                    days_since_created_apim = (datetime.now() - created_date_apim.to_pydatetime()).days
                    st.info(f"**{created_date_apim.strftime('%B %d, %Y')}**")
                    st.caption(f"({days_since_created_apim} days ago)")
                else:
                    st.info("**Not Available**")
            
            with col2:
                st.markdown("##### 🚀 Moved to Production")
                if len(prod_dates_apim) > 0:
                    prod_date_apim = pd.to_datetime(prod_dates_apim[0])
                    days_since_prod_apim = (datetime.now() - prod_date_apim.to_pydatetime()).days
                    st.success(f"**{prod_date_apim.strftime('%B %d, %Y')}**")
                    st.caption(f"({days_since_prod_apim} days ago)")
                else:
                    st.info("**Not Available**")
            
            with col3:
                st.markdown("##### ⏱️ Time to Production")
                if len(created_dates_apim) > 0 and len(prod_dates_apim) > 0:
                    created_apim = pd.to_datetime(created_dates_apim[0])
                    prod_apim = pd.to_datetime(prod_dates_apim[0])
                    time_to_prod_apim = (prod_apim - created_apim).days
                    st.metric("Days", time_to_prod_apim)
                else:
                    st.info("**Not Available**")
            
            st.markdown("<br>", unsafe_allow_html=True)
            
            st.markdown("### 📊 Proxy Age Analysis")
            if len(created_dates_apim) > 0:
                created_date_apim = pd.to_datetime(created_dates_apim[0])
                age_years_apim = (datetime.now() - created_date_apim.to_pydatetime()).days / 365.25
                
                col1, col2, col3 = st.columns(3)
                with col1:
                    st.metric("Age (Years)", f"{age_years_apim:.1f}")
                with col2:
                    st.metric("Age (Days)", f"{(datetime.now() - created_date_apim.to_pydatetime()).days}")
                with col3:
                    if age_years_apim >= 3:
                        st.warning("⚠️ Legacy Proxy (3+ years)")
                    elif age_years_apim >= 1:
                        st.info("ℹ️ Mature Proxy (1-3 years)")
                    else:
                        st.success("✅ New Proxy (<1 year)")
            else:
                st.info("Creation date not available for age analysis.")
            
            st.markdown("<br>", unsafe_allow_html=True)
            st.markdown("### 📈 Proxy Statistics")
            
            proxy_stats_apim = proxy_lifecycle_data_apim.drop_duplicates()
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                endpoint_count_apim = proxy_stats_apim["APIM Prod URL"].dropna().nunique() if "APIM Prod URL" in proxy_stats_apim.columns else 0
                st.metric("Endpoints", endpoint_count_apim)
            
            with col2:
                consumer_count_apim = proxy_stats_apim["Consumer App Name"].dropna().nunique()
                st.metric("Consumers", consumer_count_apim)
            
            with col3:
                protocol_apim = safe_get(row_apim, "API Protocol (REST / SOAP)")
                st.metric("Protocol", protocol_apim)
            
            with col4:
                auth_type_apim = safe_get(row_apim, "Authentication")
                st.metric("Authentication", auth_type_apim)
    
    with tab_chat_apim:
        st.markdown('<h2 class="section-header">💬 AI Assistant</h2>', unsafe_allow_html=True)
        st.markdown("""
        <div style="background: linear-gradient(135deg, #667EEA 0%, #764BA2 100%); 
                    padding: 1.5rem; border-radius: 10px; color: white; margin-bottom: 1.5rem;">
            <h4 style="color: white; margin: 0;">🤖 How can I help you?</h4>
            <p style="margin: 0.5rem 0 0 0; opacity: 0.9;">Ask me about quotas, URLs, lifecycle, status, protocols, impact analysis, and more!</p>
        </div>
        """, unsafe_allow_html=True)
        
        if "messages_apim" not in st.session_state:
            st.session_state.messages_apim = []
        if "last_df_apim" not in st.session_state:
            st.session_state.last_df_apim = pd.DataFrame()
        
        if not st.session_state.last_df_apim.empty:
            last_bytes_apim = df_to_excel_bytes(st.session_state.last_df_apim)
            st.download_button(
                label="📥 Download Last Result",
                data=last_bytes_apim,
                file_name="apim_chatbot_results.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                key="download_last_result_apim"
            )
            st.markdown("<br>", unsafe_allow_html=True)
        
        for msg in st.session_state.messages_apim:
            with st.chat_message(msg["role"], avatar="👤" if msg["role"] == "user" else "🤖"):
                st.write(msg["content"])
        
        user_text_apim = st.chat_input("💬 Ask me anything about this APIM proxy...", key="chat_input_apim")
        if user_text_apim:
            st.session_state.messages_apim.append({"role": "user", "content": user_text_apim})
            with st.chat_message("user", avatar="👤"):
                st.write(user_text_apim)
            
            text_apim = user_text_apim.lower()
            reply_apim = "I didn't fully get that. Try: 'quota', 'apim url', 'backend url', 'lifecycle', 'status', 'protocol and methods', 'older than 3 years', 'recent changes', 'impact', 'portfolio'."
            df_out_apim = pd.DataFrame()
            
            if any(k in text_apim for k in ["quota", "spike"]):
                q_apim = safe_get(row_apim, "Quota Limit")
                s_apim = safe_get(row_apim, "Spike Arrest")
                reply_apim = f"**Rate Limits for {selected_proxy_apim}:**\n\n- 📊 **Quota Limit:** {q_apim}\n- ⚡ **Spike Arrest:** {s_apim}"
            
            elif any(k in text_apim for k in ["apim url", "backend url", "endpoint", "url"]):
                import re
                url_pattern = r'https?://[^\s]+'
                found_urls_apim = re.findall(url_pattern, text_apim)
                
                if found_urls_apim:
                    search_url_apim = found_urls_apim[0]
                    apim_prod_match = apim_df[apim_df["APIM Prod URL"].str.contains(search_url_apim, case=False, na=False, regex=False)] if "APIM Prod URL" in apim_df.columns else pd.DataFrame()
                    backend_prod_match = apim_df[apim_df["Backend Prod URL"].str.contains(search_url_apim, case=False, na=False, regex=False)] if "Backend Prod URL" in apim_df.columns else pd.DataFrame()
                    
                    if not apim_prod_match.empty:
                        backend_urls_apim = apim_prod_match["Backend Prod URL"].dropna().unique().tolist() if "Backend Prod URL" in apim_prod_match.columns else []
                        if backend_urls_apim:
                            reply_apim = f"**Backend Prod URL(s) for APIM Prod URL:**\n\n`{search_url_apim}`\n\n**→ Backend:**\n\n"
                            reply_apim += "\n\n".join([f"• `{url}`" for url in backend_urls_apim if url])
                            df_out_apim = apim_prod_match[["APIM Prod URL", "Backend Prod URL", "Prod API Proxies"]].drop_duplicates()
                        else:
                            reply_apim = "APIM Prod URL found but no corresponding Backend Prod URL available."
                    elif not backend_prod_match.empty:
                        apim_urls_apim = backend_prod_match["APIM Prod URL"].dropna().unique().tolist() if "APIM Prod URL" in backend_prod_match.columns else []
                        if apim_urls_apim:
                            reply_apim = f"**APIM Prod URL(s) for Backend Prod URL:**\n\n`{search_url_apim}`\n\n**→ APIM:**\n\n"
                            reply_apim += "\n\n".join([f"• `{url}`" for url in apim_urls_apim if url])
                            df_out_apim = backend_prod_match[["Backend Prod URL", "APIM Prod URL", "Prod API Proxies"]].drop_duplicates()
                        else:
                            reply_apim = "Backend Prod URL found but no corresponding APIM Prod URL available."
                    else:
                        reply_apim = f"URL not found in database: `{search_url_apim}`"
                else:
                    url_cols_apim = ["APIM Prod URL", "APIM DR URL", "Backend Prod URL", "Backend DR URL", "Request Type(GET/POST/DELETE/PUT)"]
                    available_url_cols_apim = [col for col in url_cols_apim if col in apim_df.columns]
                    urls_df_apim = apim_df[apim_df["Prod API Proxies"] == selected_proxy_apim][available_url_cols_apim].drop_duplicates()
                    if urls_df_apim.empty:
                        reply_apim = "No APIM or Backend URLs found for this proxy."
                    else:
                        reply_apim = f"**Endpoints for {selected_proxy_apim}:**\n\n"
                        for _, r in urls_df_apim.iterrows():
                            if "APIM Prod URL" in r and pd.notna(r["APIM Prod URL"]) and r["APIM Prod URL"]:
                                reply_apim += f"• **APIM Prod:** `{r['APIM Prod URL']}`\n"
                            if "Backend Prod URL" in r and pd.notna(r["Backend Prod URL"]) and r["Backend Prod URL"]:
                                reply_apim += f"  **Backend Prod:** `{r['Backend Prod URL']}`\n"
                            if "Request Type(GET/POST/DELETE/PUT)" in r:
                                reply_apim += f"  **Method:** {r['Request Type(GET/POST/DELETE/PUT)']}\n\n"
                        df_out_apim = urls_df_apim
            
            elif any(k in text_apim for k in ["created", "when was"]):
                created_apim = safe_get(row_apim, "Proxy Created Date")
                reply_apim = f"Created on {created_apim}"
            
            elif any(k in text_apim for k in ["prod", "lifecycle", "move"]):
                created_apim = safe_get(row_apim, "Proxy Created Date")
                prod_apim = safe_get(row_apim, "Prod Move Date")
                reply_apim = f"Lifecycle: Created={created_apim}, PROD move={prod_apim}"
            
            elif any(k in text_apim for k in ["status", "active", "decommissioned", "decom"]):
                status_val_apim = safe_get(row_apim, "Status(A/D)")
                reply_apim = f"Status of {selected_proxy_apim}: {status_val_apim}"
            
            elif any(k in text_apim for k in ["rest", "soap", "http methods", "request type", "methods", "protocol"]):
                protocol_apim = safe_get(row_apim, "API Protocol (REST / SOAP)")
                methods_apim = safe_get(row_apim, "Request Type(GET/POST/DELETE/PUT)")
                reply_apim = f"{selected_proxy_apim} is {protocol_apim}; Methods: {methods_apim}"
            
            st.session_state.messages_apim.append({"role": "assistant", "content": reply_apim})
            with st.chat_message("assistant", avatar="🤖"):
                st.write(reply_apim)
                if not df_out_apim.empty:
                    st.dataframe(df_out_apim, width='stretch')
                    st.session_state.last_df_apim = df_out_apim
                else:
                    st.session_state.last_df_apim = pd.DataFrame()
    
    st.stop()
else:
    # =========================
    # Apigee Dashboard Code
    # =========================
    # Sidebar: Search & controls
    st.sidebar.markdown("""
    <div style="background: linear-gradient(135deg, #0F9D58 0%, #4285F4 100%); 
                padding: 1.5rem; border-radius: 10px; margin-bottom: 1.5rem;">
        <h2 style="color: white; margin: 0; font-size: 1.5rem;">📊 Apigee Dashboard</h2>
    </div>
    """, unsafe_allow_html=True)
    
    if st.sidebar.button("🏠 Back to Home", key="back_home_apigee", use_container_width=True):
        st.session_state.current_page = "home"
        st.rerun()
    
    st.sidebar.markdown("---")
    st.sidebar.markdown("""
    <div style="background: linear-gradient(135deg, #0F9D58 0%, #4285F4 100%); 
                padding: 1.5rem; border-radius: 10px; margin-bottom: 1.5rem;">
        <h2 style="color: white; margin: 0; font-size: 1.5rem;">🔍 Search & Filters</h2>
    </div>
    """, unsafe_allow_html=True)

# Check if required column exists and data is available
if "Prod API Proxies" not in proxy_df.columns:
    st.error("⚠️ **Missing column**: The Excel file must contain a 'Prod API Proxies' column in the 'API_Metadata' sheet.")
    st.stop()

proxy_list = sorted(proxy_df["Prod API Proxies"].dropna().unique().tolist())

if not proxy_list:
    st.error("⚠️ **No data**: No proxy names found in the 'Prod API Proxies' column. Please check your Excel file.")
    st.stop()

st.sidebar.markdown("### 📋 Select API Proxy")
selected_proxy = st.sidebar.selectbox("Choose a proxy to analyze", proxy_list, label_visibility="collapsed")

st.sidebar.markdown("---")

# Refresh data
if st.sidebar.button("🔄 Refresh Data", use_container_width=True):
    load_data.clear()
    proxy_df, apps_df, apim_df = load_data()
    st.sidebar.success("✅ Data refreshed!")
    st.rerun()

st.sidebar.markdown("---")
st.sidebar.markdown("""
<div style="text-align: center; color: #5F6368; font-size: 0.85rem; padding: 1rem;">
    <strong>Apigee Analytics Dashboard</strong><br>
    v1.0 | © 2026
</div>
""", unsafe_allow_html=True)

# =========================
# Header
# =========================
st.markdown("""
<div class="main-header">
    <h1>📊 Apigee Analytics Dashboard</h1>
    <p>Comprehensive API Proxy Management & Insights</p>
</div>
""", unsafe_allow_html=True)

# =========================
# Dashboard Summary Analytics
# =========================

# Calculate meaningful analytics
# Remove rows with missing proxy names first, then get unique
unique_proxies_df = proxy_df[proxy_df["Prod API Proxies"].notna()].drop_duplicates(subset=["Prod API Proxies"])

# 1. Total unique proxies (excluding NaN proxy names)
total_proxies = len(unique_proxies_df)

# 2. Active vs Decommissioned (handle NaN status values properly)
if "Status(A/D)" in unique_proxies_df.columns:
    # Convert to string, handle NaN, then filter
    status_series = unique_proxies_df["Status(A/D)"].astype(str).str.upper().str.strip()
    active_proxies = (status_series == "A").sum()
    decom_proxies = (status_series == "D").sum()
else:
    active_proxies = 0
    decom_proxies = 0
active_percentage = round((active_proxies / total_proxies * 100), 1) if total_proxies > 0 else 0

# 3. Unique Providers & Consumers
unique_providers = proxy_df["Provider App Name"].nunique() if "Provider App Name" in proxy_df.columns else 0
unique_consumers = proxy_df["Consumer App Name"].nunique() if "Consumer App Name" in proxy_df.columns else 0

# 4. REST vs SOAP breakdown
rest_count = unique_proxies_df[unique_proxies_df["API Protocol (REST / SOAP)"].str.upper() == "REST"].shape[0] if "API Protocol (REST / SOAP)" in proxy_df.columns else 0
soap_count = unique_proxies_df[unique_proxies_df["API Protocol (REST / SOAP)"].str.upper() == "SOAP"].shape[0] if "API Protocol (REST / SOAP)" in proxy_df.columns else 0

# 5. Total unique endpoints (unique Apigee URLs across all proxies)
total_endpoints = proxy_df["APIGEE URL"].dropna().nunique()

# 6. Recent activity (last 30 days)
cutoff_30days = pd.Timestamp(datetime.now() - timedelta(days=30))
recent_created = proxy_df[(proxy_df["Proxy Created Date"].notna()) & (proxy_df["Proxy Created Date"] >= cutoff_30days)]["Prod API Proxies"].nunique()
recent_moved = proxy_df[(proxy_df["Prod Move Date"].notna()) & (proxy_df["Prod Move Date"] >= cutoff_30days)]["Prod API Proxies"].nunique()
recent_activity = max(recent_created, recent_moved)

# Display metrics - Futuristic Clean Design
st.markdown("""
<div style="margin: 2.5rem 0 2rem 0; text-align: center;">
    <h2 style="color: #202124; font-size: 2rem; font-weight: 800; margin-bottom: 0.5rem; letter-spacing: -0.5px;">
        📊 Key Metrics Dashboard
    </h2>
    <p style="color: #5F6368; font-size: 1rem; margin: 0; font-weight: 500;">Real-time analytics & insights</p>
</div>
""", unsafe_allow_html=True)

# Calculate OAuth, Internet, Intranet counts
oauth_count = unique_proxies_df[unique_proxies_df["Authentication"].str.contains("Oauth", case=False, na=False)].shape[0]
internet_count = unique_proxies_df[unique_proxies_df["Internet/Intranet Exposed"].str.contains("Internet", case=False, na=False)].shape[0]
intranet_count = unique_proxies_df[unique_proxies_df["Internet/Intranet Exposed"].str.contains("Intranet", case=False, na=False)].shape[0]
internet_percentage = round((internet_count / total_proxies * 100), 1) if total_proxies > 0 else 0
intranet_percentage = round((intranet_count / total_proxies * 100), 1) if total_proxies > 0 else 0

# First row - Core Metrics (4 columns with proper spacing)
st.markdown("<div style='margin-bottom: 1.5rem;'></div>", unsafe_allow_html=True)
col1, col2, col3, col4 = st.columns(4, gap="large")

with col1:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-label">Total API Proxies</div>
        <div class="metric-value">{total_proxies}</div>
    </div>
    """, unsafe_allow_html=True)

with col2:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-label">Active APIs</div>
        <div class="metric-value">{active_proxies}<small>({active_percentage}%)</small></div>
    </div>
    """, unsafe_allow_html=True)

with col3:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-label">Decommissioned</div>
        <div class="metric-value">{decom_proxies}</div>
    </div>
    """, unsafe_allow_html=True)

with col4:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-label">Unique Endpoints</div>
        <div class="metric-value">{total_endpoints}</div>
        <div class="metric-subtext">Unique Apigee URLs</div>
    </div>
    """, unsafe_allow_html=True)

# Second row - Stakeholders & Technology
st.markdown("<div style='margin-bottom: 1.5rem;'></div>", unsafe_allow_html=True)
col5, col6, col7, col8 = st.columns(4, gap="large")

with col5:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-label">Unique Providers</div>
        <div class="metric-value">{unique_providers}</div>
    </div>
    """, unsafe_allow_html=True)

with col6:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-label">Unique Consumers</div>
        <div class="metric-value">{unique_consumers}</div>
    </div>
    """, unsafe_allow_html=True)

with col7:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-label">REST APIs</div>
        <div class="metric-value">{rest_count}</div>
    </div>
    """, unsafe_allow_html=True)

with col8:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-label">SOAP APIs</div>
        <div class="metric-value">{soap_count}</div>
    </div>
    """, unsafe_allow_html=True)

# Third row - Security & Activity
st.markdown("<div style='margin-bottom: 1.5rem;'></div>", unsafe_allow_html=True)
col9, col10, col11, col12 = st.columns(4, gap="large")

with col9:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-label">Recent Activity (30d)</div>
        <div class="metric-value">{recent_activity}</div>
    </div>
    """, unsafe_allow_html=True)

with col10:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-label">OAuth Protected</div>
        <div class="metric-value">{oauth_count}</div>
    </div>
    """, unsafe_allow_html=True)

with col11:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-label">🌐 Internet Exposed</div>
        <div class="metric-value">{internet_count}</div>
        <div class="metric-subtext">{internet_percentage}% of total</div>
    </div>
    """, unsafe_allow_html=True)

with col12:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-label">🔒 Intranet Only</div>
        <div class="metric-value">{intranet_count}</div>
        <div class="metric-subtext">{intranet_percentage}% of total</div>
    </div>
    """, unsafe_allow_html=True)

st.markdown("<div style='margin-bottom: 2rem;'></div>", unsafe_allow_html=True)

# =========================
# Tabs: Overview, Consumers, Date Filter, URL Search, Developer Apps, Lifecycle, AI Assistant
# =========================
tab_overview, tab_consumers, tab_date_filter, tab_url_search, tab_dev_apps, tab_lifecycle, tab_chat = st.tabs([
    "🔍 Overview", 
    "👥 Consumers",
    "📅 Date Filter",
    "🔗 URL Search",
    "📱 Developer Apps",
    "📈 Lifecycle", 
    "💬 AI Assistant"
])

row = get_proxy_row(proxy_df, selected_proxy)

with tab_overview:
    st.markdown(f'<h2 class="section-header">📋 {selected_proxy}</h2>', unsafe_allow_html=True)
    
    # Status badge
    status = safe_get(row, "Status(A/D)")
    status_class = "status-active" if status.upper() == "A" else "status-inactive"
    status_text = "Active ✓" if status.upper() == "A" else "Decommissioned ✗"
    st.markdown(f'<span class="{status_class}">{status_text}</span>', unsafe_allow_html=True)
    
    st.markdown("<br>", unsafe_allow_html=True)
    
    col1, col2 = st.columns(2)

    with col1:
        st.markdown("##### 🔧 Technical Details")
        st.markdown(f"""
        - **Protocol:** {safe_get(row, 'API Protocol (REST / SOAP)')}
        - **Methods:** {safe_get(row, 'Request Type(GET/POST/DELETE/PUT)')}
        - **Authentication:** {safe_get(row, 'Authentication')}
        - **Exposure:** {safe_get(row, 'Internet/Intranet Exposed')}
        """)

    with col2:
        st.markdown("##### ⚙️ Rate Limits")
        st.markdown(f"""
        - **Quota Limit:** {safe_get(row, 'Quota Limit')}
        - **Spike Arrest:** {safe_get(row, 'Spike Arrest')}
        """)

    st.markdown("<br>", unsafe_allow_html=True)
    st.markdown("##### 📝 Description")
    description = safe_get(row, 'API Description')
    st.info(description if description != "N/A" else "No description available.")
    
    st.markdown("<br>", unsafe_allow_html=True)
    st.markdown("##### 🔗 Endpoints")
    urls_df = proxy_df[proxy_df["Prod API Proxies"] == selected_proxy][ ["APIGEE URL", "Backend URL", "Request Type(GET/POST/DELETE/PUT)"] ]
    if urls_df.empty:
        st.warning("⚠️ No Apigee or Backend URLs found for this proxy.")
    else:
        st.dataframe(urls_df, width='stretch', hide_index=True)

with tab_consumers:
    st.markdown('<h2 class="section-header">👥 Consumers of {}</h2>'.format(selected_proxy), unsafe_allow_html=True)
    
    # Get all consumers for this proxy
    proxy_data = proxy_df[proxy_df["Prod API Proxies"] == selected_proxy]
    
    if proxy_data.empty:
        st.warning("⚠️ No consumer data found for this proxy.")
    else:
        # Get unique consumers
        consumers = sorted([c for c in proxy_data["Consumer App Name"].dropna().unique().tolist() if c and c != ""])
        
        if not consumers:
            st.info("ℹ️ No specific consumers identified for this proxy.")
        else:
            st.info(f"💡 **Tip:** Select a consumer to see all endpoints they consume")
            st.metric("Total Unique Consumers", len(consumers))
            
            # Selectbox for consumer selection
            selected_consumer = st.selectbox(
                "Select Consumer to View Details:",
                ["-- Select a Consumer --"] + consumers,
                key="consumer_select"
            )
            
            # Show details when consumer is selected
            if selected_consumer and selected_consumer != "-- Select a Consumer --":
                st.markdown(f"### 📊 Details for **{selected_consumer}**")
                
                # Get all endpoints for this consumer and proxy
                consumer_endpoints = proxy_data[proxy_data["Consumer App Name"] == selected_consumer]
                
                if consumer_endpoints.empty:
                    st.info("No endpoint details available.")
                else:
                    # Get unique URLs
                    apigee_urls = [url for url in consumer_endpoints["APIGEE URL"].dropna().unique().tolist() if url and url != ""]
                    backend_urls = [url for url in consumer_endpoints["Backend URL"].dropna().unique().tolist() if url and url != ""]
                    
                    # Metrics
                    col1, col2 = st.columns(2)
                    with col1:
                        st.metric("Apigee Endpoints", len(apigee_urls))
                    with col2:
                        st.metric("Backend Endpoints", len(backend_urls))
                    
                    # Show URLs in expandable sections
                    with st.expander("🔗 Apigee URLs", expanded=True):
                        if apigee_urls:
                            for url in apigee_urls:
                                st.code(url, language=None)
                        else:
                            st.info("No Apigee URLs found")
                    
                    with st.expander("🔗 Backend URLs", expanded=True):
                        if backend_urls:
                            for url in backend_urls:
                                st.code(url, language=None)
                        else:
                            st.info("No Backend URLs found")
                    
                    # Show complete details table
                    st.markdown("### 📋 Complete Endpoint Details:")
                    endpoint_details = consumer_endpoints[["APIGEE URL", "Backend URL", "Request Type(GET/POST/DELETE/PUT)"]].drop_duplicates()
                    st.dataframe(endpoint_details, width='stretch', hide_index=True)
                    
                    # Download option
                    excel_bytes = df_to_excel_bytes(endpoint_details)
                    st.download_button(
                        label=f"📥 Download {selected_consumer} Endpoints",
                        data=excel_bytes,
                        file_name=f"{selected_consumer}_{selected_proxy}_endpoints.xlsx",
                        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        key="download_consumer_endpoints",
                        width='stretch'
                    )

with tab_date_filter:
    st.markdown('<h2 class="section-header">📅 Date-Based Proxy Filter</h2>', unsafe_allow_html=True)
    st.info("💡 **Filter proxies by creation date or production move date within a specific date range**")
    
    # Filter type selection
    filter_type = st.radio(
        "Select Date Type:",
        ["📅 Proxy Created Date", "🚀 Production Move Date"],
        horizontal=True,
        key="date_filter_type"
    )
    
    # Date range selection
    col1, col2 = st.columns(2)
    
    with col1:
        start_date = st.date_input(
            "Start Date:",
            value=datetime.now().date() - timedelta(days=365),
            key="start_date"
        )
    
    with col2:
        end_date = st.date_input(
            "End Date:",
            value=datetime.now().date(),
            key="end_date"
        )
    
    # Validate date range
    if start_date > end_date:
        st.error("⚠️ Start date must be before end date!")
    else:
        # Apply filter based on type
        if filter_type == "📅 Proxy Created Date":
            date_col = "Proxy Created Date"
            filter_label = "Created"
        else:
            date_col = "Prod Move Date"
            filter_label = "Moved to Production"
        
        # Filter data
        filtered_proxies = proxy_df[
            (proxy_df[date_col].notna()) &
            (pd.to_datetime(proxy_df[date_col]).dt.date >= start_date) &
            (pd.to_datetime(proxy_df[date_col]).dt.date <= end_date)
        ]
        
        # Remove duplicates
        unique_proxies = filtered_proxies.drop_duplicates(subset=["Prod API Proxies"])
        
        if unique_proxies.empty:
            st.warning(f"⚠️ No proxies found {filter_label.lower()} between {start_date} and {end_date}")
        else:
            # Summary metrics
            st.success(f"✅ Found **{len(unique_proxies)}** unique proxies {filter_label.lower()} in this date range")
            
            col1, col2, col3 = st.columns(3)
            with col1:
                active_count = unique_proxies[unique_proxies["Status(A/D)"].str.upper() == "A"].shape[0] if "Status(A/D)" in unique_proxies.columns else 0
                st.metric("Active", active_count)
            with col2:
                rest_count = unique_proxies[unique_proxies["API Protocol (REST / SOAP)"].str.upper() == "REST"].shape[0] if "API Protocol (REST / SOAP)" in unique_proxies.columns else 0
                st.metric("REST APIs", rest_count)
            with col3:
                oauth_count = unique_proxies[unique_proxies["Authentication"].str.contains("Oauth", case=False, na=False)].shape[0]
                st.metric("OAuth Protected", oauth_count)
            
            st.markdown("### 📋 Proxy Details")
            
            # Display columns
            display_cols = ["Prod API Proxies", date_col, "Status(A/D)", "Provider App Name", "Consumer App Name"]
            available_cols = [col for col in display_cols if col in unique_proxies.columns]
            
            # Sort by date
            unique_proxies_sorted = unique_proxies.sort_values(date_col, ascending=False)
            
            st.dataframe(
                unique_proxies_sorted[available_cols],
                width='stretch',
                hide_index=True
            )
            
            # Download option
            excel_bytes = df_to_excel_bytes(unique_proxies_sorted[available_cols])
            st.download_button(
                label="📥 Download Filtered Proxies",
                data=excel_bytes,
                file_name=f"proxies_{filter_label.lower()}_{start_date}_to_{end_date}.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                key="download_date_filtered",
                width='stretch'
            )

with tab_url_search:
    st.markdown('<h2 class="section-header">🔗 URL Search & Mapping</h2>', unsafe_allow_html=True)
    st.info("💡 **Tip:** Find the corresponding URL by pasting either an Apigee or Backend URL")
    
    # URL input
    search_url = st.text_input(
        "Enter URL to search:",
        placeholder="Paste Apigee URL or Backend URL here...",
        help="Enter any part of an Apigee or Backend URL to find its mapping"
    )
    
    if search_url and len(search_url) > 10:
        # Search in both Apigee and Backend URLs
        apigee_matches = proxy_df[proxy_df["APIGEE URL"].str.contains(search_url, case=False, na=False, regex=False)]
        backend_matches = proxy_df[proxy_df["Backend URL"].str.contains(search_url, case=False, na=False, regex=False)]
        
        if not apigee_matches.empty:
            # Found in Apigee URLs
            st.success(f"✅ Found {len(apigee_matches)} matching Apigee URL(s)")
            
            # Show unique mappings
            mappings = apigee_matches[["Prod API Proxies", "APIGEE URL", "Backend URL"]].drop_duplicates()
            
            for idx, row in mappings.iterrows():
                with st.expander(f"🔍 {row['Prod API Proxies']}", expanded=True):
                    st.markdown("**Apigee URL:**")
                    st.code(row["APIGEE URL"], language=None)
                    st.markdown("**→ Corresponding Backend URL:**")
                    st.code(row["Backend URL"], language=None)
            
            # Download option
            excel_bytes = df_to_excel_bytes(mappings)
            st.download_button(
                label="📥 Download All Mappings",
                data=excel_bytes,
                file_name="url_mappings.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                key="download_apigee_mappings",
                width='stretch'
            )
        
        elif not backend_matches.empty:
            # Found in Backend URLs
            st.success(f"✅ Found {len(backend_matches)} matching Backend URL(s)")
            
            # Show unique mappings
            mappings = backend_matches[["Prod API Proxies", "Backend URL", "APIGEE URL"]].drop_duplicates()
            
            for idx, row in mappings.iterrows():
                with st.expander(f"🔍 {row['Prod API Proxies']}", expanded=True):
                    st.markdown("**Backend URL:**")
                    st.code(row["Backend URL"], language=None)
                    st.markdown("**→ Corresponding Apigee URL:**")
                    st.code(row["APIGEE URL"], language=None)
            
            # Download option
            excel_bytes = df_to_excel_bytes(mappings)
            st.download_button(
                label="📥 Download All Mappings",
                data=excel_bytes,
                file_name="url_mappings.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                key="download_backend_mappings",
                width='stretch'
            )
        
        else:
            st.warning(f"❌ No matches found for: `{search_url}`")
            st.info("💡 Try entering a different part of the URL or check for typos")
    
    elif search_url:
        st.info("⌨️ Please enter at least 10 characters to search")

with tab_dev_apps:
    st.markdown('<h2 class="section-header">📱 Developer Apps & Products</h2>', unsafe_allow_html=True)
    
    if apps_df.empty or "API Proxy Name" not in apps_df.columns:
        st.warning("⚠️ No developer apps data available. Sheet2 is required for this feature.")
    else:
        st.info("💡 **Select a Developer App and Product to see mapped API Proxies**")
        
        # Two-step selection
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("### Step 1: Select Developer App")
            all_dev_apps = sorted(apps_df["Developer App"].dropna().unique().tolist())
            selected_dev_app = st.selectbox(
                "Choose Developer App:",
                ["-- Select Developer App --"] + all_dev_apps,
                key="dev_app_selector"
            )
        
        with col2:
            st.markdown("### Step 2: Select Product")
            if selected_dev_app and selected_dev_app != "-- Select Developer App --":
                # Get products for selected developer app
                dev_app_data = apps_df[apps_df["Developer App"] == selected_dev_app]
                products_for_app = sorted(dev_app_data["Product Name"].dropna().unique().tolist())
                
                selected_product = st.selectbox(
                    "Choose Product:",
                    ["-- Select Product --"] + products_for_app,
                    key="product_selector"
                )
            else:
                selected_product = "-- Select Product --"
                st.selectbox(
                    "Choose Product:",
                    ["-- Select Product --"],
                    key="product_selector_disabled",
                    disabled=True
                )
        
        # Show results
        if selected_dev_app != "-- Select Developer App --" and selected_product != "-- Select Product --":
            st.markdown("<br>", unsafe_allow_html=True)
            st.markdown("### 📋 Mapped API Proxies")
            
            # Get API proxies for selected developer app and product
            mapped_proxies = apps_df[
                (apps_df["Developer App"] == selected_dev_app) & 
                (apps_df["Product Name"] == selected_product)
            ]["API Proxy Name"].dropna().unique().tolist()
            
            if mapped_proxies:
                st.success(f"✅ Found **{len(mapped_proxies)}** API Proxy/Proxies")
                
                # Display proxies
                for idx, proxy in enumerate(sorted(mapped_proxies), 1):
                    st.markdown(f"{idx}. `{proxy}`")
                
                # Download option
                export_data = apps_df[
                    (apps_df["Developer App"] == selected_dev_app) & 
                    (apps_df["Product Name"] == selected_product)
                ][["Developer App", "Product Name", "API Proxy Name", "Assigned To"]].drop_duplicates()
                
                excel_bytes = df_to_excel_bytes(export_data)
                st.download_button(
                    label="📥 Download Mapping Data",
                    data=excel_bytes,
                    file_name=f"{selected_dev_app}_{selected_product}_proxies.xlsx",
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    key="download_dev_app_mapping",
                    width='stretch'
                )
            else:
                st.warning(f"⚠️ No API Proxies found for Developer App **{selected_dev_app}** and Product **{selected_product}**")
        
        elif selected_dev_app != "-- Select Developer App --":
            # Show products available for selected developer app
            dev_app_data = apps_df[apps_df["Developer App"] == selected_dev_app]
            products_list = sorted(dev_app_data["Product Name"].dropna().unique().tolist())
            
            if products_list:
                st.markdown("<br>", unsafe_allow_html=True)
                st.markdown(f"### 📦 Products for {selected_dev_app}")
                st.info(f"**{len(products_list)}** products available. Please select a product to see API Proxies.")
                with st.expander("View All Products", expanded=False):
                    for prod in products_list:
                        st.write(f"• {prod}")

with tab_lifecycle:
    st.markdown(f'<h2 class="section-header">📈 Lifecycle & Timeline - {selected_proxy}</h2>', unsafe_allow_html=True)
    
    # Get proxy-specific data
    proxy_lifecycle_data = proxy_df[proxy_df["Prod API Proxies"] == selected_proxy]
    
    if proxy_lifecycle_data.empty:
        st.warning("⚠️ No lifecycle data found for this proxy.")
    else:
        # Get unique dates (in case of multiple rows)
        created_dates = proxy_lifecycle_data["Proxy Created Date"].dropna().unique()
        prod_dates = proxy_lifecycle_data["Prod Move Date"].dropna().unique()
        
        # Display lifecycle information
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.markdown("##### 📅 Created Date")
            if len(created_dates) > 0:
                created_date = pd.to_datetime(created_dates[0])
                days_since_created = (datetime.now() - created_date.to_pydatetime()).days
                st.info(f"**{created_date.strftime('%B %d, %Y')}**")
                st.caption(f"({days_since_created} days ago)")
            else:
                st.info("**Not Available**")
        
        with col2:
            st.markdown("##### 🚀 Moved to Production")
            if len(prod_dates) > 0:
                prod_date = pd.to_datetime(prod_dates[0])
                days_since_prod = (datetime.now() - prod_date.to_pydatetime()).days
                st.success(f"**{prod_date.strftime('%B %d, %Y')}**")
                st.caption(f"({days_since_prod} days ago)")
            else:
                st.info("**Not Available**")
        
        with col3:
            st.markdown("##### ⏱️ Time to Production")
            if len(created_dates) > 0 and len(prod_dates) > 0:
                created = pd.to_datetime(created_dates[0])
                prod = pd.to_datetime(prod_dates[0])
                time_to_prod = (prod - created).days
                st.metric("Days", time_to_prod)
            else:
                st.info("**Not Available**")
        
        st.markdown("<br>", unsafe_allow_html=True)
        
        # Proxy age analysis
        st.markdown("### 📊 Proxy Age Analysis")
        if len(created_dates) > 0:
            created_date = pd.to_datetime(created_dates[0])
            age_years = (datetime.now() - created_date.to_pydatetime()).days / 365.25
            
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Age (Years)", f"{age_years:.1f}")
            with col2:
                st.metric("Age (Days)", f"{(datetime.now() - created_date.to_pydatetime()).days}")
            with col3:
                if age_years >= 3:
                    st.warning("⚠️ Legacy Proxy (3+ years)")
                elif age_years >= 1:
                    st.info("ℹ️ Mature Proxy (1-3 years)")
                else:
                    st.success("✅ New Proxy (<1 year)")
        else:
            st.info("Creation date not available for age analysis.")
        
        st.markdown("<br>", unsafe_allow_html=True)
        
        # Status timeline - Get directly from proxy data (removed unnecessary section)
        # Status is already shown in Overview tab, no need to duplicate here
        
        # Additional proxy-specific metrics
        st.markdown("<br>", unsafe_allow_html=True)
        st.markdown("### 📈 Proxy Statistics")
        
        proxy_stats = proxy_lifecycle_data.drop_duplicates()
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            endpoint_count = proxy_stats["APIGEE URL"].dropna().nunique()
            st.metric("Endpoints", endpoint_count)
        
        with col2:
            consumer_count = proxy_stats["Consumer App Name"].dropna().nunique()
            st.metric("Consumers", consumer_count)
        
        with col3:
            protocol = safe_get(row, "API Protocol (REST / SOAP)")
            st.metric("Protocol", protocol)
        
        with col4:
            auth_type = safe_get(row, "Authentication")
            st.metric("Authentication", auth_type)

with tab_chat:
    st.markdown('<h2 class="section-header">💬 AI Assistant</h2>', unsafe_allow_html=True)
    st.markdown("""
    <div style="background: linear-gradient(135deg, #667EEA 0%, #764BA2 100%); 
                padding: 1.5rem; border-radius: 10px; color: white; margin-bottom: 1.5rem;">
        <h4 style="color: white; margin: 0;">🤖 How can I help you?</h4>
        <p style="margin: 0.5rem 0 0 0; opacity: 0.9;">Ask me about quotas, URLs, lifecycle, status, protocols, impact analysis, and more!</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Session state for chat and last result
    if "messages" not in st.session_state:
        st.session_state.messages = []
    if "last_df" not in st.session_state:
        st.session_state.last_df = pd.DataFrame()

    # Export last result (if any)
    if not st.session_state.last_df.empty:
        last_bytes = df_to_excel_bytes(st.session_state.last_df)
        st.download_button(
            label="📥 Download Last Result",
            data=last_bytes,
            file_name="chatbot_results.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            key="download_last_result"
        )
        st.markdown("<br>", unsafe_allow_html=True)

    # Display history
    for msg in st.session_state.messages:
        with st.chat_message(msg["role"], avatar="👤" if msg["role"] == "user" else "🤖"):
            st.write(msg["content"])

    # Chat input and intent routing
    user_text = st.chat_input("💬 Ask me anything about this proxy...")
    if user_text:
        # Add user message to history
        st.session_state.messages.append({"role": "user", "content": user_text})
        # Display user message
        with st.chat_message("user", avatar="👤"):
            st.write(user_text)

        text = user_text.lower()
        reply = "I didn't fully get that. Try: 'quota', 'products and apps', 'apigee and backend url', 'lifecycle', 'status', 'protocol and methods', 'older than 3 years', 'recent changes', 'impact', 'portfolio'."
        df_out = pd.DataFrame()

        # Handlers mapped to available columns
        if any(k in text for k in ["quota", "spike"]):
            q = safe_get(row, "Quota Limit")
            s = safe_get(row, "Spike Arrest")
            reply = f"**Rate Limits for {selected_proxy}:**\n\n- 📊 **Quota Limit:** {q}\n- ⚡ **Spike Arrest:** {s}"

        elif any(k in text for k in ["product", "developer app", "apps", "consumers"]):
            # Try Sheet2 apps data first
            if not apps_df.empty and "API Proxy Name" in apps_df.columns:
                mapped = apps_df[apps_df["API Proxy Name"] == selected_proxy]
                if mapped.empty:
                    reply = "No developer apps or products found for this proxy."
                else:
                    apps_info = mapped[["Developer App", "Product Name"]].drop_duplicates()
                    items = [f"{r['Developer App']} (Product: {r['Product Name']})" for _, r in apps_info.iterrows()]
                    reply = f"**Developer Apps & Products for {selected_proxy}:**\n\n" + "\n".join([f"• {item}" for item in items])
                    df_out = apps_info
            else:
                # Fallback to Sheet1 consumer data
                mapped = proxy_df[proxy_df["Prod API Proxies"] == selected_proxy]
                if mapped.empty:
                    reply = "No consumers or assignments found for this proxy."
                else:
                    consumer_info = mapped[["Consumer App Name", "Assigned To"]].drop_duplicates()
                    if consumer_info.empty:
                        reply = "No consumer apps found for this proxy."
                    else:
                        items = [f"{r['Consumer App Name']} (Assigned: {r['Assigned To']})" for _, r in consumer_info.iterrows()]
                        reply = f"**Consumer Apps for {selected_proxy}:**\n\n" + "\n".join([f"• {item}" for item in items])
                        df_out = consumer_info

        elif any(k in text for k in ["apigee url", "backend url", "endpoint", "url"]):
            # Check if user is asking for URL mapping (Apigee → Backend or Backend → Apigee)
            # Extract URL from text if present
            import re
            url_pattern = r'https?://[^\s]+'
            found_urls = re.findall(url_pattern, text)
            
            if found_urls:
                # User provided a URL, find the corresponding one
                search_url = found_urls[0]
                
                # Search in Apigee URLs
                apigee_match = proxy_df[proxy_df["APIGEE URL"].str.contains(search_url, case=False, na=False, regex=False)]
                if not apigee_match.empty:
                    backend_urls = apigee_match["Backend URL"].dropna().unique().tolist()
                    if backend_urls:
                        reply = f"**Backend URL(s) for Apigee URL:**\n\n`{search_url}`\n\n**→ Backend:**\n\n"
                        reply += "\n\n".join([f"• `{url}`" for url in backend_urls if url])
                        df_out = apigee_match[["APIGEE URL", "Backend URL", "Prod API Proxies"]].drop_duplicates()
                    else:
                        reply = "Apigee URL found but no corresponding Backend URL available."
                else:
                    # Search in Backend URLs
                    backend_match = proxy_df[proxy_df["Backend URL"].str.contains(search_url, case=False, na=False, regex=False)]
                    if not backend_match.empty:
                        apigee_urls = backend_match["APIGEE URL"].dropna().unique().tolist()
                        if apigee_urls:
                            reply = f"**Apigee URL(s) for Backend URL:**\n\n`{search_url}`\n\n**→ Apigee:**\n\n"
                            reply += "\n\n".join([f"• `{url}`" for url in apigee_urls if url])
                            df_out = backend_match[["Backend URL", "APIGEE URL", "Prod API Proxies"]].drop_duplicates()
                        else:
                            reply = "Backend URL found but no corresponding Apigee URL available."
                    else:
                        reply = f"URL not found in database: `{search_url}`"
            else:
                # No URL provided, show all endpoints for selected proxy
                urls_df = proxy_df[proxy_df["Prod API Proxies"] == selected_proxy][["APIGEE URL", "Backend URL", "Request Type(GET/POST/DELETE/PUT)"]].drop_duplicates()
                if urls_df.empty:
                    reply = "No Apigee or Backend URLs found for this proxy."
                else:
                    reply = f"**Endpoints for {selected_proxy}:**\n\n"
                    for _, r in urls_df.iterrows():
                        reply += f"• **Apigee:** `{r['APIGEE URL']}`\n  **Backend:** `{r['Backend URL']}`\n  **Method:** {r['Request Type(GET/POST/DELETE/PUT)']}\n\n"
                    df_out = urls_df

        elif any(k in text for k in ["created", "when was"]):
            created = safe_get(row, "Proxy Created Date")
            reply = f"Created on {created}"

        elif any(k in text for k in ["prod", "lifecycle", "move"]):
            created = safe_get(row, "Proxy Created Date")
            prod = safe_get(row, "Prod Move Date")
            reply = f"Lifecycle: Created={created}, PROD move={prod}"

        elif any(k in text for k in ["provider", "consumer"]) and not any(k in text for k in ["impact"]):
            provider = safe_get(row, "Provider App Name")
            consumer = safe_get(row, "Consumer App Name")
            reply = f"Provider App: {provider}, Consumer App: {consumer}"

        elif any(k in text for k in ["recent", "last 30", "changed", "added"]):
            cutoff = pd.Timestamp(datetime.now() - timedelta(days=30))
            recent_created = proxy_df[(proxy_df["Proxy Created Date"].notna()) & (proxy_df["Proxy Created Date"] >= cutoff)]
            recent_moved = proxy_df[(proxy_df["Prod Move Date"].notna()) & (proxy_df["Prod Move Date"] >= cutoff)]
            names = sorted(set(recent_created["Prod API Proxies"].tolist()) | set(recent_moved["Prod API Proxies"].tolist()))
            if names:
                df_out = proxy_df[proxy_df["Prod API Proxies"].isin(names)][["Prod API Proxies", "Proxy Created Date", "Prod Move Date"]]
                reply = f"Recently added or moved (30 days): {', '.join(names)}"
            else:
                reply = "No APIs added or moved to PROD in the last 30 days."

        elif any(k in text for k in ["impact", "change backend", "impacted"]):
            # Extract backend hint from text (any token resembling a URL)
            backend_hint = None
            for token in text.split():
                if token.startswith("http"):
                    backend_hint = token
                    break
            backend_hint = backend_hint or safe_get(row, "Backend URL")
            impacted = proxy_df[proxy_df["Backend URL"].astype(str).str.contains(str(backend_hint), case=False, na=False)][
                ["Prod API Proxies", "Consumer App Name"]
            ]
            if impacted.empty:
                reply = "No consumers mapped to that backend."
            else:
                items = [f"{r['Prod API Proxies']} → {r['Consumer App Name']}" for _, r in impacted.iterrows()]
                reply = "Impacted consumers: " + ", ".join(items)
                df_out = impacted

        elif any(k in text for k in ["portfolio", "how many apis", "provider"]):
            provider_id = safe_get(row, "Provider APP ID")
            portfolio = proxy_df[proxy_df["Provider APP ID"].astype(str) == str(provider_id)][["Prod API Proxies", "Status(A/D)"]]
            reply = f"Provider {provider_id} owns {len(portfolio)} proxies."
            df_out = portfolio

        elif any(k in text for k in ["older than", "older", "years"]):
            years_val = 3
            for tok in text.split():
                if tok.isdigit():
                    years_val = int(tok)
                    break
            cutoff_years = pd.Timestamp(datetime.now() - timedelta(days=365 * years_val))
            old_df = proxy_df[(proxy_df["Proxy Created Date"].notna()) & (proxy_df["Proxy Created Date"] < cutoff_years)][
                ["Prod API Proxies", "Proxy Created Date", "Status(A/D)"]
            ]
            if old_df.empty:
                reply = f"No APIs older than {years_val} years."
            else:
                names = ", ".join(old_df["Prod API Proxies"].tolist())
                reply = f"APIs older than {years_val} years: {names}"
                df_out = old_df

        elif any(k in text for k in ["status", "active", "decommissioned", "decom"]):
            if "list" in text and "active" in text:
                active_df = proxy_df[proxy_df["Status(A/D)"].str.upper() == "A"][["Prod API Proxies", "Status(A/D)"]]
                reply = f"Active APIs: {', '.join(active_df['Prod API Proxies'].tolist()) if not active_df.empty else 'None'}"
                df_out = active_df
            elif "list" in text and ("decommissioned" in text or "decom" in text or "d " in text):
                decom_df = proxy_df[proxy_df["Status(A/D)"].str.upper() == "D"][["Prod API Proxies", "Status(A/D)"]]
                reply = f"Decommissioned APIs: {', '.join(decom_df['Prod API Proxies'].tolist()) if not decom_df.empty else 'None'}"
                df_out = decom_df
            else:
                status_val = safe_get(row, "Status(A/D)")
                reply = f"Status of {selected_proxy}: {status_val}"

        elif any(k in text for k in ["rest", "soap", "http methods", "request type", "methods", "protocol"]):
            protocol = safe_get(row, "API Protocol (REST / SOAP)")
            methods = safe_get(row, "Request Type(GET/POST/DELETE/PUT)")
            reply = f"{selected_proxy} is {protocol}; Methods: {methods}"

        elif any(k in text for k in ["export", "download"]):
            if not st.session_state.last_df.empty:
                reply = "Use the 'Download last result as Excel' button above."
            else:
                reply = "No previous result to export yet. Ask a query that returns a list or table first."

        # Send reply and store last df
        st.session_state.messages.append({"role": "assistant", "content": reply})
        # Display assistant response
        with st.chat_message("assistant", avatar="🤖"):
            st.write(reply)
            # Display dataframe if available
            if not df_out.empty:
                st.dataframe(df_out, width='stretch')
                st.session_state.last_df = df_out
            else:
                st.session_state.last_df = pd.DataFrame()
