import streamlit as st
import pandas as pd
from datetime import datetime, timedelta
from io import BytesIO

# =========================
# App config
# =========================
st.set_page_config(
    page_title="Apigee Analytics Dashboard",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# =========================
# Custom CSS for beautiful UI
# =========================
st.markdown("""
<style>
    /* Main theme colors */
    :root {
        --primary-color: #0F9D58;
        --secondary-color: #4285F4;
        --accent-color: #F4B400;
        --danger-color: #DB4437;
        --bg-color: #F8F9FA;
    }
    
    /* Header styling */
    .main-header {
        background: linear-gradient(135deg, #0F9D58 0%, #4285F4 100%);
        padding: 2rem;
        border-radius: 10px;
        color: white;
        margin-bottom: 2rem;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }
    
    .main-header h1 {
        font-size: 2.5rem;
        font-weight: 700;
        margin: 0;
        color: white !important;
    }
    
    .main-header p {
        font-size: 1.1rem;
        margin: 0.5rem 0 0 0;
        opacity: 0.95;
    }
    
    /* Futuristic Metric Cards - Glassmorphism Style */
    .metric-card {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(10px);
        padding: 2rem 1.5rem;
        border-radius: 20px;
        box-shadow: 0 8px 32px rgba(15, 157, 88, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.3);
        transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        position: relative;
        overflow: hidden;
        margin-bottom: 1.5rem;
        min-height: 140px;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
    }
    
    .metric-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 4px;
        background: linear-gradient(90deg, #0F9D58 0%, #4285F4 50%, #0F9D58 100%);
        background-size: 200% 100%;
        animation: shimmer 3s infinite;
    }
    
    @keyframes shimmer {
        0% { background-position: -200% 0; }
        100% { background-position: 200% 0; }
    }
    
    .metric-card::after {
        content: '';
        position: absolute;
        top: -50%;
        right: -50%;
        width: 100%;
        height: 100%;
        background: radial-gradient(circle, rgba(15, 157, 88, 0.1) 0%, transparent 70%);
        transition: all 0.4s;
    }
    
    .metric-card:hover {
        transform: translateY(-6px);
        box-shadow: 0 12px 40px rgba(15, 157, 88, 0.2);
        border-color: rgba(15, 157, 88, 0.3);
    }
    
    .metric-card:hover::after {
        top: -30%;
        right: -30%;
    }
    
    .metric-label {
        font-size: 0.8rem;
        color: #5F6368;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 1.2px;
        margin-bottom: 1rem;
        opacity: 0.85;
        position: relative;
        z-index: 1;
    }
    
    .metric-value {
        font-size: 2.8rem;
        font-weight: 800;
        margin: 0;
        line-height: 1.1;
        background: linear-gradient(135deg, #0F9D58 0%, #4285F4 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        position: relative;
        z-index: 1;
        letter-spacing: -1px;
    }
    
    .metric-value small {
        font-size: 0.9rem;
        font-weight: 600;
        opacity: 0.8;
        -webkit-text-fill-color: #5F6368;
        display: block;
        margin-top: 0.3rem;
    }
    
    .metric-subtext {
        font-size: 0.7rem;
        color: #5F6368;
        margin-top: 0.5rem;
        opacity: 0.7;
        position: relative;
        z-index: 1;
        line-height: 1.3;
    }
    
    /* Metrics Container */
    .metrics-container {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 1.5rem;
        margin: 2rem 0;
    }
    
    @media (max-width: 1200px) {
        .metrics-container {
            grid-template-columns: repeat(2, 1fr);
        }
    }
    
    /* Status badges */
    .status-active {
        background: #E8F5E9;
        color: #2E7D32;
        padding: 0.25rem 0.75rem;
        border-radius: 12px;
        font-weight: 600;
        font-size: 0.85rem;
        display: inline-block;
    }
    
    .status-inactive {
        background: #FFEBEE;
        color: #C62828;
        padding: 0.25rem 0.75rem;
        border-radius: 12px;
        font-weight: 600;
        font-size: 0.85rem;
        display: inline-block;
    }
    
    /* Info cards */
    .info-card {
        background: linear-gradient(135deg, #667EEA 0%, #764BA2 100%);
        padding: 1.5rem;
        border-radius: 10px;
        color: white;
        margin: 1rem 0;
    }
    
    .info-card h3 {
        color: white !important;
        margin: 0 0 0.5rem 0;
    }
    
    /* Sidebar styling */
    .css-1d391kg {
        background: #F8F9FA;
    }
    
    /* Data tables - Professional Look */
    .dataframe {
        border: none !important;
        box-shadow: 0 2px 12px rgba(0,0,0,0.08);
        border-radius: 12px;
        overflow: hidden;
    }
    
    .dataframe thead {
        background: linear-gradient(135deg, #0F9D58 0%, #4285F4 100%);
        color: white;
    }
    
    .dataframe tbody tr:hover {
        background: #F5F5F5;
        transition: background 0.2s;
    }
    
    /* Tabs - Smooth and Professional */
    .stTabs [data-baseweb="tab-list"] {
        gap: 4px;
        background: #F8F9FA;
        padding: 8px 8px 0 8px;
        border-radius: 12px 12px 0 0;
    }
    
    .stTabs [data-baseweb="tab"] {
        height: 48px;
        background-color: white;
        border-radius: 10px 10px 0 0;
        padding: 0 20px;
        font-weight: 600;
        color: #5F6368;
        border: none;
        transition: all 0.3s ease;
        box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    }
    
    .stTabs [data-baseweb="tab"]:hover {
        background: #F1F3F4;
        transform: translateY(-2px);
    }
    
    .stTabs [aria-selected="true"] {
        background: linear-gradient(135deg, #0F9D58 0%, #4285F4 100%);
        color: white !important;
        box-shadow: 0 4px 12px rgba(15, 157, 88, 0.3);
        transform: translateY(-2px);
    }
    
    /* Buttons - Smooth Transitions */
    .stButton>button {
        background: linear-gradient(135deg, #0F9D58 0%, #4285F4 100%);
        color: white;
        border: none;
        padding: 0.6rem 1.8rem;
        border-radius: 10px;
        font-weight: 600;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        box-shadow: 0 2px 8px rgba(15, 157, 88, 0.2);
    }
    
    .stButton>button:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 16px rgba(15, 157, 88, 0.4);
    }
    
    .stButton>button:active {
        transform: translateY(0);
    }
    
    /* Chat messages */
    .stChatMessage {
        background: white;
        border-radius: 10px;
        padding: 1rem;
        margin: 0.5rem 0;
        box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    }
    
    /* Download buttons */
    .stDownloadButton>button {
        background: #F4B400;
        color: #202124;
        border: none;
        padding: 0.5rem 1.5rem;
        border-radius: 8px;
        font-weight: 600;
    }
    
    .stDownloadButton>button:hover {
        background: #F4B400;
        opacity: 0.9;
        transform: scale(1.05);
    }
    
    /* Section headers */
    .section-header {
        color: #202124;
        font-size: 1.5rem;
        font-weight: 700;
        margin: 2rem 0 1rem 0;
        padding-bottom: 0.5rem;
        border-bottom: 3px solid #0F9D58;
    }
    
    /* Info boxes */
    .stInfo {
        background: #E3F2FD !important;
        border-left: 4px solid #2196F3 !important;
        border-radius: 8px !important;
    }
    
    /* Success boxes */
    .stSuccess {
        background: #E8F5E9 !important;
        border-left: 4px solid #4CAF50 !important;
        border-radius: 8px !important;
    }
    
    /* Error boxes */
    .stError {
        background: #FFEBEE !important;
        border-left: 4px solid #F44336 !important;
        border-radius: 8px !important;
    }
</style>
""", unsafe_allow_html=True)

# =========================
# Data loading (Excel with two sheets)
# =========================
@st.cache_data(show_spinner=True)
def load_data(file_path: str = "apigee_data.xlsx",
              main_sheet: str = "Sheet1",
              apps_sheet: str = "Sheet2"):
    # Read main API metadata sheet
    proxy_df = pd.read_excel(file_path, sheet_name=main_sheet)
    
    # Try to read apps/products sheet (optional)
    try:
        apps_df = pd.read_excel(file_path, sheet_name=apps_sheet)
    except Exception:
        # If Sheet2 doesn't exist, create empty dataframe
        apps_df = pd.DataFrame()
    
    # Process main proxy dataframe
    df = proxy_df

    # Normalize date columns
    for col in ["Prod Move Date", "Proxy Created Date"]:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors="coerce")

    # Handle numeric ID columns specially (remove decimal points)
    id_columns = ["Provider APP ID", "Consumer App ID"]
    for col in id_columns:
        if col in df.columns:
            def clean_id(val):
                """Convert ID to clean integer string, handling floats and text."""
                if pd.isna(val):
                    return ""
                # If it's already a string (not a number), keep it
                if isinstance(val, str):
                    return val.strip()
                # If it's a number, convert to int (removes .0) then to string
                try:
                    # Convert to float first (in case it's int), then to int, then string
                    return str(int(float(val)))
                except (ValueError, TypeError):
                    # If conversion fails, just stringify it
                    return str(val)
            
            df[col] = df[col].apply(clean_id)
    
    # Normalize text columns to avoid None and NaN
    text_columns = [
        "API Protocol (REST / SOAP)",
        "Request Type(GET/POST/DELETE/PUT)",
        "Status(A/D)",
        "Prod API Proxies",
        "Provider App Name",
        "Consumer App Name",
        "APIGEE URL",
        "Backend URL",
        "Quota Limit",
        "Spike Arrest",
        "API Description",
        "Authentication",
        "Internet/Intranet Exposed",
        "Assigned To",
    ]
    for col in text_columns:
        if col in df.columns:
            # Fill NaN first, then convert to string
            df[col] = df[col].fillna("").astype(str)
            # Replace string 'nan' with empty string
            df[col] = df[col].replace(['nan', 'None', 'NaN'], "")
    
    # Process apps dataframe if it exists
    if not apps_df.empty:
        for col in ["API Proxy Name", "Product Name", "Developer App", "Assigned To"]:
            if col in apps_df.columns:
                apps_df[col] = apps_df[col].fillna("").astype(str)
                apps_df[col] = apps_df[col].replace(['nan', 'None', 'NaN'], "")

    return df, apps_df

# =========================
# Utilities
# =========================
def df_to_excel_bytes(df: pd.DataFrame, sheet_name: str = "results") -> bytes:
    output = BytesIO()
    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name=sheet_name)
    return output.getvalue()

def get_proxy_row(df: pd.DataFrame, proxy_name: str) -> pd.DataFrame:
    return df[df["Prod API Proxies"] == proxy_name]

def safe_get(row, col: str):
    """
    Safely get a value from a dataframe row or series, handling NaN, empty, and None values.
    Handles both DataFrame and Series objects.
    If the first row has NaN/empty, it will search through all rows to find a valid value.
    """
    try:
        # Handle empty case
        if hasattr(row, 'empty') and row.empty:
            return "N/A"
        
        # Handle Series (single row)
        if isinstance(row, pd.Series):
            if col not in row.index:
                return "N/A"
            val = row[col]
            if pd.isna(val):
                return "N/A"
            val_str = str(val).strip()
            if val_str == "" or val_str.lower() in ["nan", "none"]:
                return "N/A"
            return val_str
        
        # Handle DataFrame (multiple rows)
        if isinstance(row, pd.DataFrame):
            if col not in row.columns:
                return "N/A"
            
            # Try all rows in the dataframe to find the first valid value
            for idx in range(len(row)):
                val = row[col].iloc[idx]
                
                # Skip if NaN
                if pd.isna(val):
                    continue
                
                # Convert to string and clean up
                val_str = str(val).strip()
                
                # Skip if empty or "nan"/"none" string
                if val_str == "" or val_str.lower() in ["nan", "none"]:
                    continue
                
                # Found a valid value!
                return val_str
        
        # If it's neither Series nor DataFrame, return N/A
        return "N/A"
        
    except (AttributeError, TypeError, KeyError, IndexError) as e:
        return "N/A"

# =========================
# Load data (with error handling)
# =========================
try:
    proxy_df, apps_df = load_data()
except FileNotFoundError:
    st.error("⚠️ **File not found**: `apigee_data.xlsx` is required but not found in the current directory.")
    st.info("Please ensure the Excel file exists with sheets 'Sheet1' and 'Sheet2'.")
    st.stop()
except Exception as e:
    st.error(f"⚠️ **Error loading data**: {str(e)}")
    st.stop()

# =========================
# Sidebar: Search & controls
# =========================
st.sidebar.markdown("""
<div style="background: linear-gradient(135deg, #0F9D58 0%, #4285F4 100%); 
            padding: 1.5rem; border-radius: 10px; margin-bottom: 1.5rem;">
    <h2 style="color: white; margin: 0; font-size: 1.5rem;">🔍 Search & Filters</h2>
</div>
""", unsafe_allow_html=True)

# Check if required column exists and data is available
if "Prod API Proxies" not in proxy_df.columns:
    st.error("⚠️ **Missing column**: The Excel file must contain a 'Prod API Proxies' column in the 'API_Metadata' sheet.")
    st.stop()

proxy_list = sorted(proxy_df["Prod API Proxies"].dropna().unique().tolist())

if not proxy_list:
    st.error("⚠️ **No data**: No proxy names found in the 'Prod API Proxies' column. Please check your Excel file.")
    st.stop()

st.sidebar.markdown("### 📋 Select API Proxy")
selected_proxy = st.sidebar.selectbox("Choose a proxy to analyze", proxy_list, label_visibility="collapsed")

st.sidebar.markdown("---")

# Refresh data
if st.sidebar.button("🔄 Refresh Data", use_container_width=True):
    load_data.clear()
    proxy_df, apps_df = load_data()
    st.sidebar.success("✅ Data refreshed!")

st.sidebar.markdown("---")
st.sidebar.markdown("""
<div style="text-align: center; color: #5F6368; font-size: 0.85rem; padding: 1rem;">
    <strong>Apigee Analytics Dashboard</strong><br>
    v1.0 | © 2026
</div>
""", unsafe_allow_html=True)

# =========================
# Header
# =========================
st.markdown("""
<div class="main-header">
    <h1>📊 Apigee Analytics Dashboard</h1>
    <p>Comprehensive API Proxy Management & Insights</p>
</div>
""", unsafe_allow_html=True)

# =========================
# Dashboard Summary Analytics
# =========================

# Calculate meaningful analytics
unique_proxies_df = proxy_df.drop_duplicates(subset=["Prod API Proxies"])

# 1. Total unique proxies
total_proxies = unique_proxies_df["Prod API Proxies"].nunique()

# 2. Active vs Decommissioned
active_proxies = unique_proxies_df[unique_proxies_df["Status(A/D)"].str.upper() == "A"].shape[0] if "Status(A/D)" in proxy_df.columns else 0
decom_proxies = unique_proxies_df[unique_proxies_df["Status(A/D)"].str.upper() == "D"].shape[0] if "Status(A/D)" in proxy_df.columns else 0
active_percentage = round((active_proxies / total_proxies * 100), 1) if total_proxies > 0 else 0

# 3. Unique Providers & Consumers
unique_providers = proxy_df["Provider App Name"].nunique() if "Provider App Name" in proxy_df.columns else 0
unique_consumers = proxy_df["Consumer App Name"].nunique() if "Consumer App Name" in proxy_df.columns else 0

# 4. REST vs SOAP breakdown
rest_count = unique_proxies_df[unique_proxies_df["API Protocol (REST / SOAP)"].str.upper() == "REST"].shape[0] if "API Protocol (REST / SOAP)" in proxy_df.columns else 0
soap_count = unique_proxies_df[unique_proxies_df["API Protocol (REST / SOAP)"].str.upper() == "SOAP"].shape[0] if "API Protocol (REST / SOAP)" in proxy_df.columns else 0

# 5. Total unique endpoints (unique Apigee URLs across all proxies)
total_endpoints = proxy_df["APIGEE URL"].dropna().nunique()

# 6. Recent activity (last 30 days)
cutoff_30days = pd.Timestamp(datetime.now() - timedelta(days=30))
recent_created = proxy_df[(proxy_df["Proxy Created Date"].notna()) & (proxy_df["Proxy Created Date"] >= cutoff_30days)]["Prod API Proxies"].nunique()
recent_moved = proxy_df[(proxy_df["Prod Move Date"].notna()) & (proxy_df["Prod Move Date"] >= cutoff_30days)]["Prod API Proxies"].nunique()
recent_activity = max(recent_created, recent_moved)

# Display metrics - Futuristic Clean Design
st.markdown("""
<div style="margin: 2.5rem 0 2rem 0; text-align: center;">
    <h2 style="color: #202124; font-size: 2rem; font-weight: 800; margin-bottom: 0.5rem; letter-spacing: -0.5px;">
        📊 Key Metrics Dashboard
    </h2>
    <p style="color: #5F6368; font-size: 1rem; margin: 0; font-weight: 500;">Real-time analytics & insights</p>
</div>
""", unsafe_allow_html=True)

# Calculate OAuth, Internet, Intranet counts
oauth_count = unique_proxies_df[unique_proxies_df["Authentication"].str.contains("Oauth", case=False, na=False)].shape[0]
internet_count = unique_proxies_df[unique_proxies_df["Internet/Intranet Exposed"].str.contains("Internet", case=False, na=False)].shape[0]
intranet_count = unique_proxies_df[unique_proxies_df["Internet/Intranet Exposed"].str.contains("Intranet", case=False, na=False)].shape[0]
internet_percentage = round((internet_count / total_proxies * 100), 1) if total_proxies > 0 else 0
intranet_percentage = round((intranet_count / total_proxies * 100), 1) if total_proxies > 0 else 0

# First row - Core Metrics (4 columns with proper spacing)
st.markdown("<div style='margin-bottom: 1.5rem;'></div>", unsafe_allow_html=True)
col1, col2, col3, col4 = st.columns(4, gap="large")

with col1:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-label">Total API Proxies</div>
        <div class="metric-value">{total_proxies}</div>
    </div>
    """, unsafe_allow_html=True)

with col2:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-label">Active APIs</div>
        <div class="metric-value">{active_proxies}<small>({active_percentage}%)</small></div>
    </div>
    """, unsafe_allow_html=True)

with col3:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-label">Decommissioned</div>
        <div class="metric-value">{decom_proxies}</div>
    </div>
    """, unsafe_allow_html=True)

with col4:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-label">Unique Endpoints</div>
        <div class="metric-value">{total_endpoints}</div>
        <div class="metric-subtext">Unique Apigee URLs</div>
    </div>
    """, unsafe_allow_html=True)

# Second row - Stakeholders & Technology
st.markdown("<div style='margin-bottom: 1.5rem;'></div>", unsafe_allow_html=True)
col5, col6, col7, col8 = st.columns(4, gap="large")

with col5:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-label">Unique Providers</div>
        <div class="metric-value">{unique_providers}</div>
    </div>
    """, unsafe_allow_html=True)

with col6:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-label">Unique Consumers</div>
        <div class="metric-value">{unique_consumers}</div>
    </div>
    """, unsafe_allow_html=True)

with col7:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-label">REST APIs</div>
        <div class="metric-value">{rest_count}</div>
    </div>
    """, unsafe_allow_html=True)

with col8:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-label">SOAP APIs</div>
        <div class="metric-value">{soap_count}</div>
    </div>
    """, unsafe_allow_html=True)

# Third row - Security & Activity
st.markdown("<div style='margin-bottom: 1.5rem;'></div>", unsafe_allow_html=True)
col9, col10, col11, col12 = st.columns(4, gap="large")

with col9:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-label">Recent Activity (30d)</div>
        <div class="metric-value">{recent_activity}</div>
    </div>
    """, unsafe_allow_html=True)

with col10:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-label">OAuth Protected</div>
        <div class="metric-value">{oauth_count}</div>
    </div>
    """, unsafe_allow_html=True)

with col11:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-label">🌐 Internet Exposed</div>
        <div class="metric-value">{internet_count}</div>
        <div class="metric-subtext">{internet_percentage}% of total</div>
    </div>
    """, unsafe_allow_html=True)

with col12:
    st.markdown(f"""
    <div class="metric-card">
        <div class="metric-label">🔒 Intranet Only</div>
        <div class="metric-value">{intranet_count}</div>
        <div class="metric-subtext">{intranet_percentage}% of total</div>
    </div>
    """, unsafe_allow_html=True)

st.markdown("<div style='margin-bottom: 2rem;'></div>", unsafe_allow_html=True)

# =========================
# Tabs: Overview, Consumers, Date Filter, URL Search, Lifecycle, AI Assistant
# =========================
tab_overview, tab_consumers, tab_date_filter, tab_url_search, tab_lifecycle, tab_chat = st.tabs([
    "🔍 Overview", 
    "👥 Consumers",
    "📅 Date Filter",
    "🔗 URL Search",
    "📈 Lifecycle", 
    "💬 AI Assistant"
])

row = get_proxy_row(proxy_df, selected_proxy)

with tab_overview:
    st.markdown(f'<h2 class="section-header">📋 {selected_proxy}</h2>', unsafe_allow_html=True)
    
    # Status badge
    status = safe_get(row, "Status(A/D)")
    status_class = "status-active" if status.upper() == "A" else "status-inactive"
    status_text = "Active ✓" if status.upper() == "A" else "Decommissioned ✗"
    st.markdown(f'<span class="{status_class}">{status_text}</span>', unsafe_allow_html=True)
    
    st.markdown("<br>", unsafe_allow_html=True)
    
    col1, col2 = st.columns(2)

    with col1:
        st.markdown("##### 🔧 Technical Details")
        st.markdown(f"""
        - **Protocol:** {safe_get(row, 'API Protocol (REST / SOAP)')}
        - **Methods:** {safe_get(row, 'Request Type(GET/POST/DELETE/PUT)')}
        - **Authentication:** {safe_get(row, 'Authentication')}
        - **Exposure:** {safe_get(row, 'Internet/Intranet Exposed')}
        """)

    with col2:
        st.markdown("##### ⚙️ Rate Limits")
        st.markdown(f"""
        - **Quota Limit:** {safe_get(row, 'Quota Limit')}
        - **Spike Arrest:** {safe_get(row, 'Spike Arrest')}
        """)

    st.markdown("<br>", unsafe_allow_html=True)
    st.markdown("##### 📝 Description")
    description = safe_get(row, 'API Description')
    st.info(description if description != "N/A" else "No description available.")
    
    st.markdown("<br>", unsafe_allow_html=True)
    st.markdown("##### 🔗 Endpoints")
    urls_df = proxy_df[proxy_df["Prod API Proxies"] == selected_proxy][ ["APIGEE URL", "Backend URL", "Request Type(GET/POST/DELETE/PUT)"] ]
    if urls_df.empty:
        st.warning("⚠️ No Apigee or Backend URLs found for this proxy.")
    else:
        st.dataframe(urls_df, width='stretch', hide_index=True)

with tab_consumers:
    st.markdown('<h2 class="section-header">👥 Consumers of {}</h2>'.format(selected_proxy), unsafe_allow_html=True)
    
    # Get all consumers for this proxy
    proxy_data = proxy_df[proxy_df["Prod API Proxies"] == selected_proxy]
    
    if proxy_data.empty:
        st.warning("⚠️ No consumer data found for this proxy.")
    else:
        # Get unique consumers
        consumers = sorted([c for c in proxy_data["Consumer App Name"].dropna().unique().tolist() if c and c != ""])
        
        if not consumers:
            st.info("ℹ️ No specific consumers identified for this proxy.")
        else:
            st.info(f"💡 **Tip:** Select a consumer to see all endpoints they consume")
            st.metric("Total Unique Consumers", len(consumers))
            
            # Selectbox for consumer selection
            selected_consumer = st.selectbox(
                "Select Consumer to View Details:",
                ["-- Select a Consumer --"] + consumers,
                key="consumer_select"
            )
            
            # Show details when consumer is selected
            if selected_consumer and selected_consumer != "-- Select a Consumer --":
                st.markdown(f"### 📊 Details for **{selected_consumer}**")
                
                # Get all endpoints for this consumer and proxy
                consumer_endpoints = proxy_data[proxy_data["Consumer App Name"] == selected_consumer]
                
                if consumer_endpoints.empty:
                    st.info("No endpoint details available.")
                else:
                    # Get unique URLs
                    apigee_urls = [url for url in consumer_endpoints["APIGEE URL"].dropna().unique().tolist() if url and url != ""]
                    backend_urls = [url for url in consumer_endpoints["Backend URL"].dropna().unique().tolist() if url and url != ""]
                    
                    # Metrics
                    col1, col2 = st.columns(2)
                    with col1:
                        st.metric("Apigee Endpoints", len(apigee_urls))
                    with col2:
                        st.metric("Backend Endpoints", len(backend_urls))
                    
                    # Show URLs in expandable sections
                    with st.expander("🔗 Apigee URLs", expanded=True):
                        if apigee_urls:
                            for url in apigee_urls:
                                st.code(url, language=None)
                        else:
                            st.info("No Apigee URLs found")
                    
                    with st.expander("🔗 Backend URLs", expanded=True):
                        if backend_urls:
                            for url in backend_urls:
                                st.code(url, language=None)
                        else:
                            st.info("No Backend URLs found")
                    
                    # Show complete details table
                    st.markdown("### 📋 Complete Endpoint Details:")
                    endpoint_details = consumer_endpoints[["APIGEE URL", "Backend URL", "Request Type(GET/POST/DELETE/PUT)"]].drop_duplicates()
                    st.dataframe(endpoint_details, width='stretch', hide_index=True)
                    
                    # Download option
                    excel_bytes = df_to_excel_bytes(endpoint_details)
                    st.download_button(
                        label=f"📥 Download {selected_consumer} Endpoints",
                        data=excel_bytes,
                        file_name=f"{selected_consumer}_{selected_proxy}_endpoints.xlsx",
                        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        key="download_consumer_endpoints",
                        width='stretch'
                    )

with tab_date_filter:
    st.markdown('<h2 class="section-header">📅 Date-Based Proxy Filter</h2>', unsafe_allow_html=True)
    st.info("💡 **Filter proxies by creation date or production move date within a specific date range**")
    
    # Filter type selection
    filter_type = st.radio(
        "Select Date Type:",
        ["📅 Proxy Created Date", "🚀 Production Move Date"],
        horizontal=True,
        key="date_filter_type"
    )
    
    # Date range selection
    col1, col2 = st.columns(2)
    
    with col1:
        start_date = st.date_input(
            "Start Date:",
            value=datetime.now().date() - timedelta(days=365),
            key="start_date"
        )
    
    with col2:
        end_date = st.date_input(
            "End Date:",
            value=datetime.now().date(),
            key="end_date"
        )
    
    # Validate date range
    if start_date > end_date:
        st.error("⚠️ Start date must be before end date!")
    else:
        # Apply filter based on type
        if filter_type == "📅 Proxy Created Date":
            date_col = "Proxy Created Date"
            filter_label = "Created"
        else:
            date_col = "Prod Move Date"
            filter_label = "Moved to Production"
        
        # Filter data
        filtered_proxies = proxy_df[
            (proxy_df[date_col].notna()) &
            (pd.to_datetime(proxy_df[date_col]).dt.date >= start_date) &
            (pd.to_datetime(proxy_df[date_col]).dt.date <= end_date)
        ]
        
        # Remove duplicates
        unique_proxies = filtered_proxies.drop_duplicates(subset=["Prod API Proxies"])
        
        if unique_proxies.empty:
            st.warning(f"⚠️ No proxies found {filter_label.lower()} between {start_date} and {end_date}")
        else:
            # Summary metrics
            st.success(f"✅ Found **{len(unique_proxies)}** unique proxies {filter_label.lower()} in this date range")
            
            col1, col2, col3 = st.columns(3)
            with col1:
                active_count = unique_proxies[unique_proxies["Status(A/D)"].str.upper() == "A"].shape[0] if "Status(A/D)" in unique_proxies.columns else 0
                st.metric("Active", active_count)
            with col2:
                rest_count = unique_proxies[unique_proxies["API Protocol (REST / SOAP)"].str.upper() == "REST"].shape[0] if "API Protocol (REST / SOAP)" in unique_proxies.columns else 0
                st.metric("REST APIs", rest_count)
            with col3:
                oauth_count = unique_proxies[unique_proxies["Authentication"].str.contains("Oauth", case=False, na=False)].shape[0]
                st.metric("OAuth Protected", oauth_count)
            
            st.markdown("### 📋 Proxy Details")
            
            # Display columns
            display_cols = ["Prod API Proxies", date_col, "Status(A/D)", "Provider App Name", "Consumer App Name"]
            available_cols = [col for col in display_cols if col in unique_proxies.columns]
            
            # Sort by date
            unique_proxies_sorted = unique_proxies.sort_values(date_col, ascending=False)
            
            st.dataframe(
                unique_proxies_sorted[available_cols],
                width='stretch',
                hide_index=True
            )
            
            # Download option
            excel_bytes = df_to_excel_bytes(unique_proxies_sorted[available_cols])
            st.download_button(
                label="📥 Download Filtered Proxies",
                data=excel_bytes,
                file_name=f"proxies_{filter_label.lower()}_{start_date}_to_{end_date}.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                key="download_date_filtered",
                width='stretch'
            )

with tab_url_search:
    st.markdown('<h2 class="section-header">🔗 URL Search & Mapping</h2>', unsafe_allow_html=True)
    st.info("💡 **Tip:** Find the corresponding URL by pasting either an Apigee or Backend URL")
    
    # URL input
    search_url = st.text_input(
        "Enter URL to search:",
        placeholder="Paste Apigee URL or Backend URL here...",
        help="Enter any part of an Apigee or Backend URL to find its mapping"
    )
    
    if search_url and len(search_url) > 10:
        # Search in both Apigee and Backend URLs
        apigee_matches = proxy_df[proxy_df["APIGEE URL"].str.contains(search_url, case=False, na=False, regex=False)]
        backend_matches = proxy_df[proxy_df["Backend URL"].str.contains(search_url, case=False, na=False, regex=False)]
        
        if not apigee_matches.empty:
            # Found in Apigee URLs
            st.success(f"✅ Found {len(apigee_matches)} matching Apigee URL(s)")
            
            # Show unique mappings
            mappings = apigee_matches[["Prod API Proxies", "APIGEE URL", "Backend URL"]].drop_duplicates()
            
            for idx, row in mappings.iterrows():
                with st.expander(f"🔍 {row['Prod API Proxies']}", expanded=True):
                    st.markdown("**Apigee URL:**")
                    st.code(row["APIGEE URL"], language=None)
                    st.markdown("**→ Corresponding Backend URL:**")
                    st.code(row["Backend URL"], language=None)
            
            # Download option
            excel_bytes = df_to_excel_bytes(mappings)
            st.download_button(
                label="📥 Download All Mappings",
                data=excel_bytes,
                file_name="url_mappings.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                key="download_apigee_mappings",
                width='stretch'
            )
        
        elif not backend_matches.empty:
            # Found in Backend URLs
            st.success(f"✅ Found {len(backend_matches)} matching Backend URL(s)")
            
            # Show unique mappings
            mappings = backend_matches[["Prod API Proxies", "Backend URL", "APIGEE URL"]].drop_duplicates()
            
            for idx, row in mappings.iterrows():
                with st.expander(f"🔍 {row['Prod API Proxies']}", expanded=True):
                    st.markdown("**Backend URL:**")
                    st.code(row["Backend URL"], language=None)
                    st.markdown("**→ Corresponding Apigee URL:**")
                    st.code(row["APIGEE URL"], language=None)
            
            # Download option
            excel_bytes = df_to_excel_bytes(mappings)
            st.download_button(
                label="📥 Download All Mappings",
                data=excel_bytes,
                file_name="url_mappings.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                key="download_backend_mappings",
                width='stretch'
            )
        
        else:
            st.warning(f"❌ No matches found for: `{search_url}`")
            st.info("💡 Try entering a different part of the URL or check for typos")
    
    elif search_url:
        st.info("⌨️ Please enter at least 10 characters to search")

with tab_lifecycle:
    st.markdown(f'<h2 class="section-header">📈 Lifecycle & Timeline - {selected_proxy}</h2>', unsafe_allow_html=True)
    
    # Get proxy-specific data
    proxy_lifecycle_data = proxy_df[proxy_df["Prod API Proxies"] == selected_proxy]
    
    if proxy_lifecycle_data.empty:
        st.warning("⚠️ No lifecycle data found for this proxy.")
    else:
        # Get unique dates (in case of multiple rows)
        created_dates = proxy_lifecycle_data["Proxy Created Date"].dropna().unique()
        prod_dates = proxy_lifecycle_data["Prod Move Date"].dropna().unique()
        
        # Display lifecycle information
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.markdown("##### 📅 Created Date")
            if len(created_dates) > 0:
                created_date = pd.to_datetime(created_dates[0])
                days_since_created = (datetime.now() - created_date.to_pydatetime()).days
                st.info(f"**{created_date.strftime('%B %d, %Y')}**")
                st.caption(f"({days_since_created} days ago)")
            else:
                st.info("**Not Available**")
        
        with col2:
            st.markdown("##### 🚀 Moved to Production")
            if len(prod_dates) > 0:
                prod_date = pd.to_datetime(prod_dates[0])
                days_since_prod = (datetime.now() - prod_date.to_pydatetime()).days
                st.success(f"**{prod_date.strftime('%B %d, %Y')}**")
                st.caption(f"({days_since_prod} days ago)")
            else:
                st.info("**Not Available**")
        
        with col3:
            st.markdown("##### ⏱️ Time to Production")
            if len(created_dates) > 0 and len(prod_dates) > 0:
                created = pd.to_datetime(created_dates[0])
                prod = pd.to_datetime(prod_dates[0])
                time_to_prod = (prod - created).days
                st.metric("Days", time_to_prod)
            else:
                st.info("**Not Available**")
        
        st.markdown("<br>", unsafe_allow_html=True)
        
        # Proxy age analysis
        st.markdown("### 📊 Proxy Age Analysis")
        if len(created_dates) > 0:
            created_date = pd.to_datetime(created_dates[0])
            age_years = (datetime.now() - created_date.to_pydatetime()).days / 365.25
            
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Age (Years)", f"{age_years:.1f}")
            with col2:
                st.metric("Age (Days)", f"{(datetime.now() - created_date.to_pydatetime()).days}")
            with col3:
                if age_years >= 3:
                    st.warning("⚠️ Legacy Proxy (3+ years)")
                elif age_years >= 1:
                    st.info("ℹ️ Mature Proxy (1-3 years)")
                else:
                    st.success("✅ New Proxy (<1 year)")
        else:
            st.info("Creation date not available for age analysis.")
        
        st.markdown("<br>", unsafe_allow_html=True)
        
        # Status timeline
        st.markdown("### 🔄 Status Timeline")
        status = safe_get(row, "Status(A/D)")
        if status.upper() == "A":
            st.success(f"✅ **Status: Active** - This proxy is currently active and in use.")
        else:
            st.warning(f"⚠️ **Status: Decommissioned** - This proxy has been decommissioned.")
        
        # Additional proxy-specific metrics
        st.markdown("<br>", unsafe_allow_html=True)
        st.markdown("### 📈 Proxy Statistics")
        
        proxy_stats = proxy_lifecycle_data.drop_duplicates()
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            endpoint_count = proxy_stats["APIGEE URL"].dropna().nunique()
            st.metric("Endpoints", endpoint_count)
        
        with col2:
            consumer_count = proxy_stats["Consumer App Name"].dropna().nunique()
            st.metric("Consumers", consumer_count)
        
        with col3:
            protocol = safe_get(row, "API Protocol (REST / SOAP)")
            st.metric("Protocol", protocol)
        
        with col4:
            auth_type = safe_get(row, "Authentication")
            st.metric("Authentication", auth_type)

with tab_chat:
    st.markdown('<h2 class="section-header">💬 AI Assistant</h2>', unsafe_allow_html=True)
    st.markdown("""
    <div style="background: linear-gradient(135deg, #667EEA 0%, #764BA2 100%); 
                padding: 1.5rem; border-radius: 10px; color: white; margin-bottom: 1.5rem;">
        <h4 style="color: white; margin: 0;">🤖 How can I help you?</h4>
        <p style="margin: 0.5rem 0 0 0; opacity: 0.9;">Ask me about quotas, URLs, lifecycle, status, protocols, impact analysis, and more!</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Session state for chat and last result
    if "messages" not in st.session_state:
        st.session_state.messages = []
    if "last_df" not in st.session_state:
        st.session_state.last_df = pd.DataFrame()

    # Export last result (if any)
    if not st.session_state.last_df.empty:
        last_bytes = df_to_excel_bytes(st.session_state.last_df)
        st.download_button(
            label="📥 Download Last Result",
            data=last_bytes,
            file_name="chatbot_results.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            key="download_last_result"
        )
        st.markdown("<br>", unsafe_allow_html=True)

    # Display history
    for msg in st.session_state.messages:
        with st.chat_message(msg["role"], avatar="👤" if msg["role"] == "user" else "🤖"):
            st.write(msg["content"])

    # Chat input and intent routing
    user_text = st.chat_input("💬 Ask me anything about this proxy...")
    if user_text:
        st.session_state.messages.append({"role": "user", "content": user_text})
        st.chat_message("user").write(user_text)

        text = user_text.lower()
        reply = "I didn't fully get that. Try: 'quota', 'products and apps', 'apigee and backend url', 'lifecycle', 'status', 'protocol and methods', 'older than 3 years', 'recent changes', 'impact', 'portfolio'."
        df_out = pd.DataFrame()

        # Handlers mapped to available columns
        if any(k in text for k in ["quota", "spike"]):
            q = safe_get(row, "Quota Limit")
            s = safe_get(row, "Spike Arrest")
            reply = f"**Rate Limits for {selected_proxy}:**\n\n- 📊 **Quota Limit:** {q}\n- ⚡ **Spike Arrest:** {s}"

        elif any(k in text for k in ["product", "developer app", "apps", "consumers"]):
            # Try Sheet2 apps data first
            if not apps_df.empty and "API Proxy Name" in apps_df.columns:
                mapped = apps_df[apps_df["API Proxy Name"] == selected_proxy]
                if mapped.empty:
                    reply = "No developer apps or products found for this proxy."
                else:
                    apps_info = mapped[["Developer App", "Product Name"]].drop_duplicates()
                    items = [f"{r['Developer App']} (Product: {r['Product Name']})" for _, r in apps_info.iterrows()]
                    reply = f"**Developer Apps & Products for {selected_proxy}:**\n\n" + "\n".join([f"• {item}" for item in items])
                    df_out = apps_info
            else:
                # Fallback to Sheet1 consumer data
                mapped = proxy_df[proxy_df["Prod API Proxies"] == selected_proxy]
                if mapped.empty:
                    reply = "No consumers or assignments found for this proxy."
                else:
                    consumer_info = mapped[["Consumer App Name", "Assigned To"]].drop_duplicates()
                    if consumer_info.empty:
                        reply = "No consumer apps found for this proxy."
                    else:
                        items = [f"{r['Consumer App Name']} (Assigned: {r['Assigned To']})" for _, r in consumer_info.iterrows()]
                        reply = f"**Consumer Apps for {selected_proxy}:**\n\n" + "\n".join([f"• {item}" for item in items])
                        df_out = consumer_info

        elif any(k in text for k in ["apigee url", "backend url", "endpoint", "url"]):
            # Check if user is asking for URL mapping (Apigee → Backend or Backend → Apigee)
            # Extract URL from text if present
            import re
            url_pattern = r'https?://[^\s]+'
            found_urls = re.findall(url_pattern, text)
            
            if found_urls:
                # User provided a URL, find the corresponding one
                search_url = found_urls[0]
                
                # Search in Apigee URLs
                apigee_match = proxy_df[proxy_df["APIGEE URL"].str.contains(search_url, case=False, na=False, regex=False)]
                if not apigee_match.empty:
                    backend_urls = apigee_match["Backend URL"].dropna().unique().tolist()
                    if backend_urls:
                        reply = f"**Backend URL(s) for Apigee URL:**\n\n`{search_url}`\n\n**→ Backend:**\n\n"
                        reply += "\n\n".join([f"• `{url}`" for url in backend_urls if url])
                        df_out = apigee_match[["APIGEE URL", "Backend URL", "Prod API Proxies"]].drop_duplicates()
                    else:
                        reply = "Apigee URL found but no corresponding Backend URL available."
                else:
                    # Search in Backend URLs
                    backend_match = proxy_df[proxy_df["Backend URL"].str.contains(search_url, case=False, na=False, regex=False)]
                    if not backend_match.empty:
                        apigee_urls = backend_match["APIGEE URL"].dropna().unique().tolist()
                        if apigee_urls:
                            reply = f"**Apigee URL(s) for Backend URL:**\n\n`{search_url}`\n\n**→ Apigee:**\n\n"
                            reply += "\n\n".join([f"• `{url}`" for url in apigee_urls if url])
                            df_out = backend_match[["Backend URL", "APIGEE URL", "Prod API Proxies"]].drop_duplicates()
                        else:
                            reply = "Backend URL found but no corresponding Apigee URL available."
                    else:
                        reply = f"URL not found in database: `{search_url}`"
            else:
                # No URL provided, show all endpoints for selected proxy
                urls_df = proxy_df[proxy_df["Prod API Proxies"] == selected_proxy][["APIGEE URL", "Backend URL", "Request Type(GET/POST/DELETE/PUT)"]].drop_duplicates()
                if urls_df.empty:
                    reply = "No Apigee or Backend URLs found for this proxy."
                else:
                    reply = f"**Endpoints for {selected_proxy}:**\n\n"
                    for _, r in urls_df.iterrows():
                        reply += f"• **Apigee:** `{r['APIGEE URL']}`\n  **Backend:** `{r['Backend URL']}`\n  **Method:** {r['Request Type(GET/POST/DELETE/PUT)']}\n\n"
                    df_out = urls_df

        elif any(k in text for k in ["created", "when was"]):
            created = safe_get(row, "Proxy Created Date")
            reply = f"Created on {created}"

        elif any(k in text for k in ["prod", "lifecycle", "move"]):
            created = safe_get(row, "Proxy Created Date")
            prod = safe_get(row, "Prod Move Date")
            reply = f"Lifecycle: Created={created}, PROD move={prod}"

        elif any(k in text for k in ["provider", "consumer"]) and not any(k in text for k in ["impact"]):
            provider = safe_get(row, "Provider App Name")
            consumer = safe_get(row, "Consumer App Name")
            reply = f"Provider App: {provider}, Consumer App: {consumer}"

        elif any(k in text for k in ["recent", "last 30", "changed", "added"]):
            cutoff = pd.Timestamp(datetime.now() - timedelta(days=30))
            recent_created = proxy_df[(proxy_df["Proxy Created Date"].notna()) & (proxy_df["Proxy Created Date"] >= cutoff)]
            recent_moved = proxy_df[(proxy_df["Prod Move Date"].notna()) & (proxy_df["Prod Move Date"] >= cutoff)]
            names = sorted(set(recent_created["Prod API Proxies"].tolist()) | set(recent_moved["Prod API Proxies"].tolist()))
            if names:
                df_out = proxy_df[proxy_df["Prod API Proxies"].isin(names)][["Prod API Proxies", "Proxy Created Date", "Prod Move Date"]]
                reply = f"Recently added or moved (30 days): {', '.join(names)}"
            else:
                reply = "No APIs added or moved to PROD in the last 30 days."

        elif any(k in text for k in ["impact", "change backend", "impacted"]):
            # Extract backend hint from text (any token resembling a URL)
            backend_hint = None
            for token in text.split():
                if token.startswith("http"):
                    backend_hint = token
                    break
            backend_hint = backend_hint or safe_get(row, "Backend URL")
            impacted = proxy_df[proxy_df["Backend URL"].astype(str).str.contains(str(backend_hint), case=False, na=False)][
                ["Prod API Proxies", "Consumer App Name"]
            ]
            if impacted.empty:
                reply = "No consumers mapped to that backend."
            else:
                items = [f"{r['Prod API Proxies']} → {r['Consumer App Name']}" for _, r in impacted.iterrows()]
                reply = "Impacted consumers: " + ", ".join(items)
                df_out = impacted

        elif any(k in text for k in ["portfolio", "how many apis", "provider"]):
            provider_id = safe_get(row, "Provider APP ID")
            portfolio = proxy_df[proxy_df["Provider APP ID"].astype(str) == str(provider_id)][["Prod API Proxies", "Status(A/D)"]]
            reply = f"Provider {provider_id} owns {len(portfolio)} proxies."
            df_out = portfolio

        elif any(k in text for k in ["older than", "older", "years"]):
            years_val = 3
            for tok in text.split():
                if tok.isdigit():
                    years_val = int(tok)
                    break
            cutoff_years = pd.Timestamp(datetime.now() - timedelta(days=365 * years_val))
            old_df = proxy_df[(proxy_df["Proxy Created Date"].notna()) & (proxy_df["Proxy Created Date"] < cutoff_years)][
                ["Prod API Proxies", "Proxy Created Date", "Status(A/D)"]
            ]
            if old_df.empty:
                reply = f"No APIs older than {years_val} years."
            else:
                names = ", ".join(old_df["Prod API Proxies"].tolist())
                reply = f"APIs older than {years_val} years: {names}"
                df_out = old_df

        elif any(k in text for k in ["status", "active", "decommissioned", "decom"]):
            if "list" in text and "active" in text:
                active_df = proxy_df[proxy_df["Status(A/D)"].str.upper() == "A"][["Prod API Proxies", "Status(A/D)"]]
                reply = f"Active APIs: {', '.join(active_df['Prod API Proxies'].tolist()) if not active_df.empty else 'None'}"
                df_out = active_df
            elif "list" in text and ("decommissioned" in text or "decom" in text or "d " in text):
                decom_df = proxy_df[proxy_df["Status(A/D)"].str.upper() == "D"][["Prod API Proxies", "Status(A/D)"]]
                reply = f"Decommissioned APIs: {', '.join(decom_df['Prod API Proxies'].tolist()) if not decom_df.empty else 'None'}"
                df_out = decom_df
            else:
                status_val = safe_get(row, "Status(A/D)")
                reply = f"Status of {selected_proxy}: {status_val}"

        elif any(k in text for k in ["rest", "soap", "http methods", "request type", "methods", "protocol"]):
            protocol = safe_get(row, "API Protocol (REST / SOAP)")
            methods = safe_get(row, "Request Type(GET/POST/DELETE/PUT)")
            reply = f"{selected_proxy} is {protocol}; Methods: {methods}"

        elif any(k in text for k in ["export", "download"]):
            if not st.session_state.last_df.empty:
                reply = "Use the 'Download last result as Excel' button above."
            else:
                reply = "No previous result to export yet. Ask a query that returns a list or table first."

        # Send reply and store last df
        st.session_state.messages.append({"role": "assistant", "content": reply})
        st.chat_message("assistant").write(reply)
        if not df_out.empty:
            st.session_state.last_df = df_out