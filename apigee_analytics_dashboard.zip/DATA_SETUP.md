# 📊 Data File Setup

## Required Data File

Place your Excel file named `apigee_data.xlsx` in the project root directory.

### Excel File Structure:

**Sheet Name:** `Sheet1`

**Required Columns:**
1. Assigned To
2. Prod API Proxies
3. API Description
4. Provider APP ID
5. Provider App Name
6. Consumer App ID
7. Consumer App Name
8. APIGEE URL
9. Backend URL
10. Authentication
11. Internet/Intranet Exposed
12. Status(A/D)
13. API Protocol (REST / SOAP)
14. Request Type(GET/POST/DELETE/PUT)
15. Prod Move Date
16. Proxy Created Date
17. Quota Limit
18. Spike Arrest

### Sample Data Format:

| Assigned To | Prod API Proxies | Status(A/D) | API Protocol | ...
|-------------|------------------|-------------|--------------|
| John Doe    | my-api-proxy     | A           | REST         | ...

### Notes:

- **File Name:** Must be exactly `apigee_data.xlsx`
- **Sheet Name:** Must be exactly `Sheet1`
- **Column Names:** Must match exactly (case-sensitive)
- **Status Values:** Use "A" for Active, "D" for Decommissioned
- **Dates:** Any common date format (MM/DD/YYYY, DD/MM/YYYY, etc.)

### Security Note:

⚠️ **Do NOT commit your actual data file to Git!**

The `.gitignore` file is configured to exclude `*.xlsx` files to keep your data private and secure.

Each user should place their own `apigee_data.xlsx` file in the project directory after cloning/downloading the repository.
