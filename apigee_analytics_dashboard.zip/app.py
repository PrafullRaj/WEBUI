import streamlit as st
import pandas as pd
from datetime import datetime, timedelta
from io import BytesIO

# =========================
# App config
# =========================
st.set_page_config(
    page_title="Apigee Analytics Dashboard",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# =========================
# Custom CSS for beautiful UI
# =========================
st.markdown("""
<style>
    /* Main theme colors */
    :root {
        --primary-color: #0F9D58;
        --secondary-color: #4285F4;
        --accent-color: #F4B400;
        --danger-color: #DB4437;
        --bg-color: #F8F9FA;
    }
    
    /* Header styling */
    .main-header {
        background: linear-gradient(135deg, #0F9D58 0%, #4285F4 100%);
        padding: 2rem;
        border-radius: 10px;
        color: white;
        margin-bottom: 2rem;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }
    
    .main-header h1 {
        font-size: 2.5rem;
        font-weight: 700;
        margin: 0;
        color: white !important;
    }
    
    .main-header p {
        font-size: 1.1rem;
        margin: 0.5rem 0 0 0;
        opacity: 0.95;
    }
    
    /* Metric cards */
    .metric-card {
        background: white;
        padding: 1.5rem;
        border-radius: 10px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        border-left: 4px solid #0F9D58;
        transition: transform 0.2s, box-shadow 0.2s;
    }
    
    .metric-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.12);
    }
    
    .metric-label {
        font-size: 0.9rem;
        color: #5F6368;
        font-weight: 500;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    
    .metric-value {
        font-size: 2rem;
        font-weight: 700;
        color: #202124;
        margin-top: 0.5rem;
    }
    
    /* Status badges */
    .status-active {
        background: #E8F5E9;
        color: #2E7D32;
        padding: 0.25rem 0.75rem;
        border-radius: 12px;
        font-weight: 600;
        font-size: 0.85rem;
        display: inline-block;
    }
    
    .status-inactive {
        background: #FFEBEE;
        color: #C62828;
        padding: 0.25rem 0.75rem;
        border-radius: 12px;
        font-weight: 600;
        font-size: 0.85rem;
        display: inline-block;
    }
    
    /* Info cards */
    .info-card {
        background: linear-gradient(135deg, #667EEA 0%, #764BA2 100%);
        padding: 1.5rem;
        border-radius: 10px;
        color: white;
        margin: 1rem 0;
    }
    
    .info-card h3 {
        color: white !important;
        margin: 0 0 0.5rem 0;
    }
    
    /* Sidebar styling */
    .css-1d391kg {
        background: #F8F9FA;
    }
    
    /* Data tables */
    .dataframe {
        border: none !important;
        box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        border-radius: 8px;
    }
    
    /* Tabs */
    .stTabs [data-baseweb="tab-list"] {
        gap: 8px;
    }
    
    .stTabs [data-baseweb="tab"] {
        height: 50px;
        background-color: white;
        border-radius: 8px 8px 0 0;
        padding: 0 24px;
        font-weight: 600;
        color: #5F6368;
        border: 1px solid #E8EAED;
        border-bottom: none;
    }
    
    .stTabs [aria-selected="true"] {
        background: linear-gradient(135deg, #0F9D58 0%, #4285F4 100%);
        color: white !important;
    }
    
    /* Buttons */
    .stButton>button {
        background: linear-gradient(135deg, #0F9D58 0%, #4285F4 100%);
        color: white;
        border: none;
        padding: 0.5rem 1.5rem;
        border-radius: 8px;
        font-weight: 600;
        transition: all 0.3s;
    }
    
    .stButton>button:hover {
        transform: scale(1.05);
        box-shadow: 0 4px 12px rgba(15, 157, 88, 0.3);
    }
    
    /* Chat messages */
    .stChatMessage {
        background: white;
        border-radius: 10px;
        padding: 1rem;
        margin: 0.5rem 0;
        box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    }
    
    /* Download buttons */
    .stDownloadButton>button {
        background: #F4B400;
        color: #202124;
        border: none;
        padding: 0.5rem 1.5rem;
        border-radius: 8px;
        font-weight: 600;
    }
    
    .stDownloadButton>button:hover {
        background: #F4B400;
        opacity: 0.9;
        transform: scale(1.05);
    }
    
    /* Section headers */
    .section-header {
        color: #202124;
        font-size: 1.5rem;
        font-weight: 700;
        margin: 2rem 0 1rem 0;
        padding-bottom: 0.5rem;
        border-bottom: 3px solid #0F9D58;
    }
    
    /* Info boxes */
    .stInfo {
        background: #E3F2FD !important;
        border-left: 4px solid #2196F3 !important;
        border-radius: 8px !important;
    }
    
    /* Success boxes */
    .stSuccess {
        background: #E8F5E9 !important;
        border-left: 4px solid #4CAF50 !important;
        border-radius: 8px !important;
    }
    
    /* Error boxes */
    .stError {
        background: #FFEBEE !important;
        border-left: 4px solid #F44336 !important;
        border-radius: 8px !important;
    }
</style>
""", unsafe_allow_html=True)

# =========================
# Data loading (single Excel sheet)
# =========================
@st.cache_data(show_spinner=True)
def load_data(file_path: str = "apigee_data.xlsx",
              sheet_name: str = "Sheet1"):
    df = pd.read_excel(file_path, sheet_name=sheet_name)

    # Normalize date columns
    for col in ["Prod Move Date", "Proxy Created Date"]:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors="coerce")

    # Normalize text columns to avoid None
    for col in [
        "API Protocol (REST / SOAP)",
        "Request Type(GET/POST/DELETE/PUT)",
        "Status(A/D)",
        "Prod API Proxies",
        "Provider App Name",
        "Consumer App Name",
        "APIGEE URL",
        "Backend URL",
        "Quota Limit",
        "Spike Arrest",
        "API Description",
        "Provider APP ID",
        "Consumer App ID",
        "Authentication",
        "Internet/Intranet Exposed",
        "Assigned To",
    ]:
        if col in df.columns:
            df[col] = df[col].astype(str).fillna("")

    return df

# =========================
# Utilities
# =========================
def df_to_excel_bytes(df: pd.DataFrame, sheet_name: str = "results") -> bytes:
    output = BytesIO()
    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name=sheet_name)
    return output.getvalue()

def get_proxy_row(df: pd.DataFrame, proxy_name: str) -> pd.DataFrame:
    return df[df["Prod API Proxies"] == proxy_name]

def safe_get(row: pd.DataFrame, col: str):
    if row.empty or col not in row.columns:
        return "N/A"
    val = row[col].iloc[0]
    if pd.isna(val):
        return "N/A"
    return val

# =========================
# Load data (with error handling)
# =========================
try:
    proxy_df = load_data()
except FileNotFoundError:
    st.error("⚠️ **File not found**: `apigee_data.xlsx` is required but not found in the current directory.")
    st.info("Please ensure the Excel file exists with a sheet named 'Sheet1'.")
    st.stop()
except Exception as e:
    st.error(f"⚠️ **Error loading data**: {str(e)}")
    st.stop()

# =========================
# Sidebar: Search & controls
# =========================
st.sidebar.markdown("""
<div style="background: linear-gradient(135deg, #0F9D58 0%, #4285F4 100%); 
            padding: 1.5rem; border-radius: 10px; margin-bottom: 1.5rem;">
    <h2 style="color: white; margin: 0; font-size: 1.5rem;">🔍 Search & Filters</h2>
</div>
""", unsafe_allow_html=True)

# Check if required column exists and data is available
if "Prod API Proxies" not in proxy_df.columns:
    st.error("⚠️ **Missing column**: The Excel file must contain a 'Prod API Proxies' column in the 'API_Metadata' sheet.")
    st.stop()

proxy_list = sorted(proxy_df["Prod API Proxies"].dropna().unique().tolist())

if not proxy_list:
    st.error("⚠️ **No data**: No proxy names found in the 'Prod API Proxies' column. Please check your Excel file.")
    st.stop()

st.sidebar.markdown("### 📋 Select API Proxy")
selected_proxy = st.sidebar.selectbox("Choose a proxy to analyze", proxy_list, label_visibility="collapsed")

st.sidebar.markdown("---")
st.sidebar.markdown("### 🎯 Quick Filters")

status_options = ["A", "D"]
protocol_options = ["REST", "SOAP"]
status_filter = st.sidebar.multiselect("📊 Status", options=status_options, default=[])
protocol_filter = st.sidebar.multiselect("🔌 Protocol", options=protocol_options, default=[])

# Filter summary (for discovery)
filtered_df = proxy_df.copy()
if status_filter and "Status(A/D)" in filtered_df.columns:
    filtered_df = filtered_df[filtered_df["Status(A/D)"].isin(status_filter)]
if protocol_filter and "API Protocol (REST / SOAP)" in filtered_df.columns:
    filtered_df = filtered_df[filtered_df["API Protocol (REST / SOAP)"].isin(protocol_filter)]

st.sidebar.markdown(f"""
<div style="background: #E8F5E9; padding: 1rem; border-radius: 8px; border-left: 4px solid #4CAF50;">
    <strong>Filtered Results:</strong> {len(filtered_df)} proxies
</div>
""", unsafe_allow_html=True)

st.sidebar.markdown("---")

# Refresh data
if st.sidebar.button("🔄 Refresh Data", use_container_width=True):
    load_data.clear()
    proxy_df = load_data()
    st.sidebar.success("✅ Data refreshed!")

st.sidebar.markdown("---")
st.sidebar.markdown("""
<div style="text-align: center; color: #5F6368; font-size: 0.85rem; padding: 1rem;">
    <strong>Apigee Analytics Dashboard</strong><br>
    v1.0 | © 2026
</div>
""", unsafe_allow_html=True)

# =========================
# Header
# =========================
st.markdown("""
<div class="main-header">
    <h1>📊 Apigee Analytics Dashboard</h1>
    <p>Comprehensive API Proxy Management & Insights</p>
</div>
""", unsafe_allow_html=True)

# =========================
# Dashboard Summary Stats
# =========================
col1, col2, col3, col4 = st.columns(4)

total_proxies = proxy_df["Prod API Proxies"].nunique()
active_proxies = proxy_df[proxy_df["Status(A/D)"].str.upper() == "A"]["Prod API Proxies"].nunique() if "Status(A/D)" in proxy_df.columns else 0
total_consumers = proxy_df["Consumer App Name"].nunique() if "Consumer App Name" in proxy_df.columns else 0
rest_count = proxy_df[proxy_df["API Protocol (REST / SOAP)"].str.upper() == "REST"]["Prod API Proxies"].nunique() if "API Protocol (REST / SOAP)" in proxy_df.columns else 0

with col1:
    st.markdown("""
    <div class="metric-card">
        <div class="metric-label">Total Proxies</div>
        <div class="metric-value" style="color: #4285F4;">""" + str(total_proxies) + """</div>
    </div>
    """, unsafe_allow_html=True)

with col2:
    st.markdown("""
    <div class="metric-card">
        <div class="metric-label">Active APIs</div>
        <div class="metric-value" style="color: #0F9D58;">""" + str(active_proxies) + """</div>
    </div>
    """, unsafe_allow_html=True)

with col3:
    st.markdown("""
    <div class="metric-card">
        <div class="metric-label">Consumer Apps</div>
        <div class="metric-value" style="color: #F4B400;">""" + str(total_consumers) + """</div>
    </div>
    """, unsafe_allow_html=True)

with col4:
    st.markdown("""
    <div class="metric-card">
        <div class="metric-label">REST APIs</div>
        <div class="metric-value" style="color: #DB4437;">""" + str(rest_count) + """</div>
    </div>
    """, unsafe_allow_html=True)

st.markdown("<br>", unsafe_allow_html=True)

# =========================
# Tabs: Overview, Consumers, Lifecycle, Chatbot
# =========================
tab_overview, tab_consumers, tab_lifecycle, tab_chat = st.tabs([
    "🔍 Overview", 
    "👥 Consumers", 
    "📈 Lifecycle", 
    "💬 Chatbot"
])

row = get_proxy_row(proxy_df, selected_proxy)

with tab_overview:
    st.markdown(f'<h2 class="section-header">📋 {selected_proxy}</h2>', unsafe_allow_html=True)
    
    # Status badge
    status = safe_get(row, "Status(A/D)")
    status_class = "status-active" if status.upper() == "A" else "status-inactive"
    status_text = "Active ✓" if status.upper() == "A" else "Decommissioned ✗"
    st.markdown(f'<span class="{status_class}">{status_text}</span>', unsafe_allow_html=True)
    
    st.markdown("<br>", unsafe_allow_html=True)
    
    col1, col2, col3 = st.columns(3)

    with col1:
        st.markdown("##### 🔧 Technical Details")
        st.markdown(f"""
        - **Protocol:** {safe_get(row, 'API Protocol (REST / SOAP)')}
        - **Methods:** {safe_get(row, 'Request Type(GET/POST/DELETE/PUT)')}
        - **Authentication:** {safe_get(row, 'Authentication')}
        - **Exposure:** {safe_get(row, 'Internet/Intranet Exposed')}
        """)

    with col2:
        st.markdown("##### 🏢 Provider & Consumer")
        st.markdown(f"""
        - **Provider ID:** {safe_get(row, 'Provider APP ID')}
        - **Provider App:** {safe_get(row, 'Provider App Name')}
        - **Consumer ID:** {safe_get(row, 'Consumer App ID')}
        - **Consumer App:** {safe_get(row, 'Consumer App Name')}
        """)

    with col3:
        st.markdown("##### ⚙️ Rate Limits")
        st.markdown(f"""
        - **Quota Limit:** {safe_get(row, 'Quota Limit')}
        - **Spike Arrest:** {safe_get(row, 'Spike Arrest')}
        - **Assigned To:** {safe_get(row, 'Assigned To')}
        """)

    st.markdown("<br>", unsafe_allow_html=True)
    st.markdown("##### 📝 Description")
    description = safe_get(row, 'API Description')
    st.info(description if description != "N/A" else "No description available.")
    
    st.markdown("<br>", unsafe_allow_html=True)
    st.markdown("##### 🔗 Endpoints")
    urls_df = proxy_df[proxy_df["Prod API Proxies"] == selected_proxy][ ["APIGEE URL", "Backend URL", "Request Type(GET/POST/DELETE/PUT)"] ]
    if urls_df.empty:
        st.warning("⚠️ No Apigee or Backend URLs found for this proxy.")
    else:
        st.dataframe(urls_df, use_container_width=True, hide_index=True)

with tab_consumers:
    st.markdown('<h2 class="section-header">👥 Consumers & Assignments</h2>', unsafe_allow_html=True)
    apps_for_proxy = proxy_df[proxy_df["Prod API Proxies"] == selected_proxy]
    
    if apps_for_proxy.empty:
        st.warning("⚠️ No data found for this proxy.")
    else:
        # Show consumer apps and assigned to information
        display_cols = ["Consumer App Name", "Consumer App ID", "Assigned To"]
        if "Provider App Name" in apps_for_proxy.columns:
            display_cols.insert(0, "Provider App Name")
        available_cols = [col for col in display_cols if col in apps_for_proxy.columns]
        
        unique_consumers = apps_for_proxy[available_cols].drop_duplicates()
        
        # Summary metrics
        col1, col2 = st.columns(2)
        with col1:
            st.metric("Total Consumer Apps", len(unique_consumers["Consumer App Name"].unique()))
        with col2:
            st.metric("Unique Consumers", len(unique_consumers))
        
        st.markdown("<br>", unsafe_allow_html=True)
        st.dataframe(unique_consumers, use_container_width=True, hide_index=True)
        
        st.markdown("<br>", unsafe_allow_html=True)
        excel_bytes = df_to_excel_bytes(unique_consumers)
        st.download_button(
            label="📥 Download Consumers & Assignments",
            data=excel_bytes,
            file_name=f"{selected_proxy}_consumers_assignments.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            key="download_consumers_products"
        )

with tab_lifecycle:
    st.markdown('<h2 class="section-header">📈 Lifecycle & Timeline</h2>', unsafe_allow_html=True)
    
    # Current proxy lifecycle
    col1, col2 = st.columns(2)
    created = safe_get(row, "Proxy Created Date")
    prod = safe_get(row, "Prod Move Date")
    
    with col1:
        st.markdown("##### 📅 Created Date")
        st.info(f"**{created}**")
    
    with col2:
        st.markdown("##### 🚀 Moved to PROD")
        st.info(f"**{prod}**")

    # Discovery helpers
    st.markdown("<br><br>", unsafe_allow_html=True)
    st.markdown('<h3 class="section-header">🔍 Portfolio Discovery</h3>', unsafe_allow_html=True)

    # Recently added/moved (last 30 days)
    st.markdown("##### 🆕 Recent Activity (Last 30 Days)")
    cutoff = pd.Timestamp(datetime.now() - timedelta(days=30))
    recent_created = proxy_df[(proxy_df["Proxy Created Date"].notna()) & (proxy_df["Proxy Created Date"] >= cutoff)]
    recent_moved = proxy_df[(proxy_df["Prod Move Date"].notna()) & (proxy_df["Prod Move Date"] >= cutoff)]
    names_recent = sorted(set(recent_created["Prod API Proxies"].tolist()) | set(recent_moved["Prod API Proxies"].tolist()))
    
    if names_recent:
        st.success(f"✅ **{len(names_recent)} APIs** recently added or moved:\n\n" + ', '.join(names_recent))
    else:
        st.info("No recent activity in the last 30 days.")

    st.markdown("<br>", unsafe_allow_html=True)
    
    # Older than X years
    st.markdown("##### 📊 Legacy API Analysis")
    years = st.slider("🔍 Show APIs older than (years)", 1, 10, 3, help="Identify legacy APIs that may need review")
    cutoff_years = pd.Timestamp(datetime.now() - timedelta(days=365 * years))
    old_df = proxy_df[(proxy_df["Proxy Created Date"].notna()) & (proxy_df["Proxy Created Date"] < cutoff_years)][
        ["Prod API Proxies", "Proxy Created Date", "Status(A/D)"]
    ].drop_duplicates()
    
    if old_df.empty:
        st.info(f"✅ No APIs older than {years} years found.")
    else:
        st.warning(f"⚠️ Found **{len(old_df)}** APIs older than {years} years:")
        st.dataframe(old_df, use_container_width=True, hide_index=True)
        
        st.markdown("<br>", unsafe_allow_html=True)
        old_bytes = df_to_excel_bytes(old_df)
        st.download_button(
            label=f"📥 Download Legacy APIs ({years}+ years)",
            data=old_bytes,
            file_name=f"apis_older_than_{years}_years.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            key="download_older_than"
        )

with tab_chat:
    st.markdown('<h2 class="section-header">💬 AI Assistant</h2>', unsafe_allow_html=True)
    st.markdown("""
    <div style="background: linear-gradient(135deg, #667EEA 0%, #764BA2 100%); 
                padding: 1.5rem; border-radius: 10px; color: white; margin-bottom: 1.5rem;">
        <h4 style="color: white; margin: 0;">🤖 How can I help you?</h4>
        <p style="margin: 0.5rem 0 0 0; opacity: 0.9;">Ask me about quotas, URLs, lifecycle, status, protocols, impact analysis, and more!</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Session state for chat and last result
    if "messages" not in st.session_state:
        st.session_state.messages = []
    if "last_df" not in st.session_state:
        st.session_state.last_df = pd.DataFrame()

    # Export last result (if any)
    if not st.session_state.last_df.empty:
        last_bytes = df_to_excel_bytes(st.session_state.last_df)
        st.download_button(
            label="📥 Download Last Result",
            data=last_bytes,
            file_name="chatbot_results.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            key="download_last_result"
        )
        st.markdown("<br>", unsafe_allow_html=True)

    # Display history
    for msg in st.session_state.messages:
        with st.chat_message(msg["role"], avatar="👤" if msg["role"] == "user" else "🤖"):
            st.write(msg["content"])

    # Chat input and intent routing
    user_text = st.chat_input("💬 Ask me anything about this proxy...")
    if user_text:
        st.session_state.messages.append({"role": "user", "content": user_text})
        st.chat_message("user").write(user_text)

        text = user_text.lower()
        reply = "I didn't fully get that. Try: 'quota', 'products and apps', 'apigee and backend url', 'lifecycle', 'status', 'protocol and methods', 'older than 3 years', 'recent changes', 'impact', 'portfolio'."
        df_out = pd.DataFrame()

        # Handlers mapped to available columns
        if any(k in text for k in ["quota", "spike"]):
            q = safe_get(row, "Quota Limit")
            s = safe_get(row, "Spike Arrest")
            reply = f"Quota: {q}, Spike Arrest: {s}"

        elif any(k in text for k in ["product", "developer app", "apps", "consumers"]):
            mapped = proxy_df[proxy_df["Prod API Proxies"] == selected_proxy]
            if mapped.empty:
                reply = "No consumers or assignments found for this proxy."
            else:
                # Get unique consumer apps and assigned to
                consumer_info = mapped[["Consumer App Name", "Assigned To"]].drop_duplicates()
                if consumer_info.empty:
                    reply = "No consumer apps found for this proxy."
                else:
                    items = [f"{r['Consumer App Name']} (Assigned: {r['Assigned To']})" for _, r in consumer_info.iterrows()]
                    reply = "Consumer apps and assignments: " + ", ".join(items)
                    df_out = consumer_info

        elif any(k in text for k in ["apigee url", "backend url", "endpoint", "url"]):
           urls_df = proxy_df[proxy_df["Prod API Proxies"] == selected_proxy][ ["APIGEE URL", "Backend URL", "Request Type(GET/POST/DELETE/PUT)"] ]
           if urls_df.empty:
               reply = "No Apigee or Backend URLs found."
           else:
               reply = "Endpoints:\n" + "\n".join( f"Apigee: {r['APIGEE URL']} → Backend: {r['Backend URL']} (Method: {r['Request Type(GET/POST/DELETE/PUT)']})" for _, r in urls_df.iterrows() )
               df_out = urls_df

        elif any(k in text for k in ["created", "when was"]):
            created = safe_get(row, "Proxy Created Date")
            reply = f"Created on {created}"

        elif any(k in text for k in ["prod", "lifecycle", "move"]):
            created = safe_get(row, "Proxy Created Date")
            prod = safe_get(row, "Prod Move Date")
            reply = f"Lifecycle: Created={created}, PROD move={prod}"

        elif any(k in text for k in ["provider", "consumer"]) and not any(k in text for k in ["impact"]):
            provider = safe_get(row, "Provider App Name")
            consumer = safe_get(row, "Consumer App Name")
            reply = f"Provider App: {provider}, Consumer App: {consumer}"

        elif any(k in text for k in ["recent", "last 30", "changed", "added"]):
            cutoff = pd.Timestamp(datetime.now() - timedelta(days=30))
            recent_created = proxy_df[(proxy_df["Proxy Created Date"].notna()) & (proxy_df["Proxy Created Date"] >= cutoff)]
            recent_moved = proxy_df[(proxy_df["Prod Move Date"].notna()) & (proxy_df["Prod Move Date"] >= cutoff)]
            names = sorted(set(recent_created["Prod API Proxies"].tolist()) | set(recent_moved["Prod API Proxies"].tolist()))
            if names:
                df_out = proxy_df[proxy_df["Prod API Proxies"].isin(names)][["Prod API Proxies", "Proxy Created Date", "Prod Move Date"]]
                reply = f"Recently added or moved (30 days): {', '.join(names)}"
            else:
                reply = "No APIs added or moved to PROD in the last 30 days."

        elif any(k in text for k in ["impact", "change backend", "impacted"]):
            # Extract backend hint from text (any token resembling a URL)
            backend_hint = None
            for token in text.split():
                if token.startswith("http"):
                    backend_hint = token
                    break
            backend_hint = backend_hint or safe_get(row, "Backend URL")
            impacted = proxy_df[proxy_df["Backend URL"].astype(str).str.contains(str(backend_hint), case=False, na=False)][
                ["Prod API Proxies", "Consumer App Name"]
            ]
            if impacted.empty:
                reply = "No consumers mapped to that backend."
            else:
                items = [f"{r['Prod API Proxies']} → {r['Consumer App Name']}" for _, r in impacted.iterrows()]
                reply = "Impacted consumers: " + ", ".join(items)
                df_out = impacted

        elif any(k in text for k in ["portfolio", "how many apis", "provider"]):
            provider_id = safe_get(row, "Provider APP ID")
            portfolio = proxy_df[proxy_df["Provider APP ID"].astype(str) == str(provider_id)][["Prod API Proxies", "Status(A/D)"]]
            reply = f"Provider {provider_id} owns {len(portfolio)} proxies."
            df_out = portfolio

        elif any(k in text for k in ["older than", "older", "years"]):
            years_val = 3
            for tok in text.split():
                if tok.isdigit():
                    years_val = int(tok)
                    break
            cutoff_years = pd.Timestamp(datetime.now() - timedelta(days=365 * years_val))
            old_df = proxy_df[(proxy_df["Proxy Created Date"].notna()) & (proxy_df["Proxy Created Date"] < cutoff_years)][
                ["Prod API Proxies", "Proxy Created Date", "Status(A/D)"]
            ]
            if old_df.empty:
                reply = f"No APIs older than {years_val} years."
            else:
                names = ", ".join(old_df["Prod API Proxies"].tolist())
                reply = f"APIs older than {years_val} years: {names}"
                df_out = old_df

        elif any(k in text for k in ["status", "active", "decommissioned", "decom"]):
            if "list" in text and "active" in text:
                active_df = proxy_df[proxy_df["Status(A/D)"].str.upper() == "A"][["Prod API Proxies", "Status(A/D)"]]
                reply = f"Active APIs: {', '.join(active_df['Prod API Proxies'].tolist()) if not active_df.empty else 'None'}"
                df_out = active_df
            elif "list" in text and ("decommissioned" in text or "decom" in text or "d " in text):
                decom_df = proxy_df[proxy_df["Status(A/D)"].str.upper() == "D"][["Prod API Proxies", "Status(A/D)"]]
                reply = f"Decommissioned APIs: {', '.join(decom_df['Prod API Proxies'].tolist()) if not decom_df.empty else 'None'}"
                df_out = decom_df
            else:
                status_val = safe_get(row, "Status(A/D)")
                reply = f"Status of {selected_proxy}: {status_val}"

        elif any(k in text for k in ["rest", "soap", "http methods", "request type", "methods", "protocol"]):
            protocol = safe_get(row, "API Protocol (REST / SOAP)")
            methods = safe_get(row, "Request Type(GET/POST/DELETE/PUT)")
            reply = f"{selected_proxy} is {protocol}; Methods: {methods}"

        elif any(k in text for k in ["export", "download"]):
            if not st.session_state.last_df.empty:
                reply = "Use the 'Download last result as Excel' button above."
            else:
                reply = "No previous result to export yet. Ask a query that returns a list or table first."

        # Send reply and store last df
        st.session_state.messages.append({"role": "assistant", "content": reply})
        st.chat_message("assistant").write(reply)
        if not df_out.empty:
            st.session_state.last_df = df_out