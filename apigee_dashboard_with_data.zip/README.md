# 📊 Apigee Analytics Dashboard

A beautiful, modern analytics dashboard for managing and analyzing Apigee API Proxies.

![Dashboard](https://img.shields.io/badge/Dashboard-Apigee-4285F4?style=for-the-badge)
![Python](https://img.shields.io/badge/Python-3.8+-0F9D58?style=for-the-badge&logo=python)
![Streamlit](https://img.shields.io/badge/Streamlit-1.52-FF4B4B?style=for-the-badge&logo=streamlit)

## ✨ Features

- 📈 **Dashboard Overview** - Real-time metrics and KPIs
- 🔍 **API Proxy Explorer** - Detailed proxy information
- 👥 **Consumer Management** - Track consumer apps and assignments
- 📊 **Lifecycle Analysis** - Monitor API creation and deployment
- 💬 **AI Chatbot** - Natural language queries for insights
- 📥 **Export Capabilities** - Download data as Excel files
- 🎨 **Beautiful UI** - Modern, responsive design inspired by Apigee

## 🚀 Quick Start

### Prerequisites

- Python 3.8 or higher
- pip (Python package manager)

### Installation

1. **Download/Copy these files to your system:**
   - `app.py`
   - `requirements.txt`
   - `apigee_data.xlsx`

2. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

3. **Run the application:**
   ```bash
   streamlit run app.py
   ```

4. **Open your browser:**
   - The app will automatically open at `http://localhost:8501`
   - Or manually navigate to the URL shown in the terminal

## 📋 Data Requirements

The application expects an Excel file named `apigee_data.xlsx` in the same directory with a sheet named `Sheet1` containing the following columns:

### Required Columns:
- **Prod API Proxies** - API proxy name (Required)
- **Status(A/D)** - Active/Decommissioned status
- **API Protocol (REST / SOAP)** - Protocol type
- **Request Type(GET/POST/DELETE/PUT)** - HTTP methods
- **Authentication** - Auth type
- **Internet/Intranet Exposed** - Exposure level
- **Provider APP ID** - Provider app identifier
- **Provider App Name** - Provider app name
- **Consumer App ID** - Consumer app identifier
- **Consumer App Name** - Consumer app name
- **APIGEE URL** - Apigee endpoint URL
- **Backend URL** - Backend service URL
- **Quota Limit** - Rate limit quota
- **Spike Arrest** - Spike arrest configuration
- **API Description** - Proxy description
- **Assigned To** - Team/person assignment
- **Proxy Created Date** - Creation date
- **Prod Move Date** - Production deployment date

## 📁 File Structure

```
apigee_analytics_ui/
│
├── app.py                  # Main application file
├── requirements.txt        # Python dependencies
├── apigee_data.xlsx       # Data file (required)
└── README.md              # This file
```

## 🎯 Usage

### Main Dashboard
- View key metrics: Total Proxies, Active APIs, Consumer Apps, REST APIs
- Real-time filtering by Status and Protocol

### Tabs

1. **🔍 Overview**
   - Detailed proxy information
   - Technical specifications
   - Provider and consumer details
   - Rate limits and quotas
   - API endpoints

2. **👥 Consumers**
   - Consumer app listings
   - Assignment tracking
   - Export consumer data

3. **📈 Lifecycle**
   - Creation and deployment dates
   - Recent activity (last 30 days)
   - Legacy API identification
   - Portfolio analysis

4. **💬 Chatbot**
   - Natural language queries
   - Ask about quotas, URLs, status, protocols
   - Impact analysis
   - Export query results

### Sample Chatbot Queries:
- "What's the quota for this proxy?"
- "Show me all consumers"
- "When was this API created?"
- "Show APIs older than 3 years"
- "What's the status?"
- "List all active APIs"

## 🔧 Configuration

### Changing Data Source
Edit the `load_data()` function in `app.py`:
```python
def load_data(file_path: str = "your_file.xlsx",
              sheet_name: str = "YourSheetName"):
```

### Customizing Colors
Modify the CSS variables in the `st.markdown()` section at the top of `app.py`:
```css
:root {
    --primary-color: #0F9D58;
    --secondary-color: #4285F4;
    --accent-color: #F4B400;
    --danger-color: #DB4437;
}
```

## 🐛 Troubleshooting

### Common Issues:

1. **"File not found" error**
   - Ensure `apigee_data.xlsx` is in the same directory as `app.py`
   - Check the file has a sheet named `Sheet1`

2. **"Missing column" error**
   - Verify your Excel file has the required columns
   - Column names must match exactly (case-sensitive)

3. **Import errors**
   - Run: `pip install -r requirements.txt`
   - Ensure Python 3.8+ is installed

4. **Port already in use**
   - Use a different port: `streamlit run app.py --server.port 8502`

## 📦 Dependencies

- **Streamlit** - Web application framework
- **Pandas** - Data manipulation and analysis
- **OpenPyXL** - Excel file handling

## 🌐 Deployment

### Deploy to Streamlit Cloud (Free):

1. Push your code to GitHub
2. Go to [share.streamlit.io](https://share.streamlit.io)
3. Connect your repository
4. Deploy!

### Deploy to Other Platforms:
- **Heroku**: Add `setup.sh` and `Procfile`
- **Docker**: Create `Dockerfile` with Python + Streamlit
- **AWS/Azure**: Use container services

## 📝 Notes

- The app caches data for better performance
- Use the "Refresh Data" button to reload the Excel file
- All exports are in Excel format (.xlsx)
- The app is fully responsive and works on mobile devices

## 🤝 Support

For issues or questions:
1. Check the Troubleshooting section
2. Verify your data format matches requirements
3. Ensure all dependencies are installed

## 📄 License

This project is available for internal use and modification.

---

**Made with ❤️ using Streamlit**
